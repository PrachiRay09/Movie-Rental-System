package dao;

import database.DatabaseConnection;
import model.Rental;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class RentalDAO {

    public static List<Rental> getAllRentals() {
        List<Rental> rentals = new ArrayList<>();
        String sql = "SELECT r.rental_id, m.title AS movie_title, r.rental_date, r.due_date, r.status " +
                     "FROM rentals r JOIN movies m ON r.movie_id = m.movie_id " +
                     "WHERE r.status = 'rented'";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                rentals.add(new Rental(
                        rs.getInt("rental_id"),
                        rs.getString("movie_title"),
                        rs.getDate("rental_date").toLocalDate(),
                        rs.getDate("due_date").toLocalDate(),
                        rs.getString("status")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rentals;
    }

    public static void returnRental(int rentalId) {
        String sql = "UPDATE rentals SET return_date = CURRENT_DATE, status = 'returned' WHERE rental_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, rentalId);
            stmt.executeUpdate();
            System.out.println("Movie returned successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public static boolean isMovieAvailable(int movieId) {
        String sql = "SELECT COUNT(*) FROM rentals WHERE movie_id = ? AND status = 'rented'";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, movieId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) == 0; // If count is 0, the movie is available
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public static void insertRental(int userId, int movieId) {
        String sql = "INSERT INTO rentals (user_id, movie_id, rental_date, due_date, status, late_fee) VALUES (?, ?, CURRENT_DATE, ?, 'rented', 0)";

        LocalDate dueDate = LocalDate.now().plusDays(7); // Automatically set due date 7 days from today

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userId);
            stmt.setInt(2, movieId);
            stmt.setDate(3, java.sql.Date.valueOf(dueDate));

            stmt.executeUpdate();
            System.out.println("Rental record inserted successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
