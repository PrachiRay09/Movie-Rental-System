package dao;

import database.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Movie;

public class MovieDAO {

    // INSERT a new movie
    public static void insertMovie(String title, String genre, String director, String actor, String description, String releaseDate) {
        String sql = "INSERT INTO movies (title, genre, director, actor, description, release_date) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, title);
            stmt.setString(2, genre);
            stmt.setString(3, director);
            stmt.setString(4, actor);
            stmt.setString(5, description);
            stmt.setDate(6, java.sql.Date.valueOf(releaseDate));

            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Movie inserted successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // get all movies
    public static List<Movie> getAllMovies() {
        List<Movie> movies = new ArrayList<>();
        String sql = "SELECT * FROM movies";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Movie movie = new Movie(
                    rs.getInt("movie_id"),
                    rs.getString("title"),
                    rs.getString("genre"),
                    rs.getDate("release_date").toString(),
                    rs.getString("actor"),
                    rs.getString("director"),
                    rs.getString("description")
                );
                movies.add(movie);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return movies;
    }

    // UPDATE a movie
    public static void updateMovie(int movieId, String title, String genre, String director, String actor, String description, String releaseDate) {
        String sql = "UPDATE movies SET title=?, genre=?, director=?, actor=?, description=?, release_date=? WHERE movie_id=?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, title);
            stmt.setString(2, genre);
            stmt.setString(3, director);
            stmt.setString(4, actor);
            stmt.setString(5, description);
            stmt.setDate(6, java.sql.Date.valueOf(releaseDate));
            stmt.setInt(7, movieId);

            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Movie updated successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // DELETE a movie
    public static void deleteMovie(int movieId) {
        String sql = "DELETE FROM movies WHERE movie_id=?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, movieId);
            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Movie deleted successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public static List<Movie> getAvailableMovies() {
        List<Movie> movies = new ArrayList<>();
        String sql = "SELECT * FROM movies WHERE movie_id NOT IN (SELECT movie_id FROM rentals WHERE status = 'rented')";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                String releaseDate = (rs.getDate("release_date") != null) ? rs.getDate("release_date").toString() : "Unknown";

                movies.add(new Movie(
                        rs.getInt("movie_id"),
                        rs.getString("title"),
                        rs.getString("genre"),
                        releaseDate, //passing a String
                        rs.getString("actor"),
                        rs.getString("director"),
                        rs.getString("description")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return movies;
    }

}
