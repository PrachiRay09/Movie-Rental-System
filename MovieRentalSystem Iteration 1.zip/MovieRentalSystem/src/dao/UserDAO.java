package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import database.DatabaseConnection;
import model.User;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {
	
	public static User authenticate(String username, String password) {
        String sql = "SELECT * FROM users WHERE username = ? AND password = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, username);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new User(
                        rs.getInt("user_id"),
                        rs.getString("username"),
                        rs.getString("email"),
                        rs.getString("phone_number"),
                        rs.getString("password"),
                        rs.getBoolean("status"),
                        rs.getString("first_name"),
                        rs.getString("last_name"),
                        rs.getString("address")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
	
	public static List<User> getAllUsers() {
        List<User> users = new ArrayList<>();
        String sql = "SELECT user_id, username, email, phone_number, role, status, first_name, last_name, address FROM users";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                users.add(new User(
                        rs.getInt("user_id"),
                        rs.getString("username"),
                        rs.getString("email"),
                        rs.getString("phone_number"),
                        rs.getString("role"),
                        rs.getBoolean("status"),
                        rs.getString("first_name"),
                        rs.getString("last_name"),
                        rs.getString("address")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return users;
    }
	
	public static void insertUser(String username, String email, String phone, String password, String role, boolean status, String firstName, String lastName, String address) {
	    String sql = "INSERT INTO users (username, email, phone_number, password, role, status, first_name, last_name, address) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

	    try (Connection conn = DatabaseConnection.getConnection();
	         PreparedStatement stmt = conn.prepareStatement(sql)) {

	        stmt.setString(1, username);
	        stmt.setString(2, email);
	        stmt.setString(3, phone);
	        stmt.setString(4, password);
	        stmt.setString(5, role);
	        stmt.setBoolean(6, status);
	        stmt.setString(7, firstName);
	        stmt.setString(8, lastName);
	        stmt.setString(9, address.isEmpty() ? null : address); // Fix for NULL address

	        stmt.executeUpdate();
	        System.out.println("User added successfully!");
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

		public static void updateUser(int userId, String username, String email, String phone, String password, String role, boolean status, String firstName, String lastName, String address) {
		    String sql = "UPDATE users SET username=?, email=?, phone_number=?, password=?, role=?, status=?, first_name=?, last_name=?, address=? WHERE user_id=?";

		    try (Connection conn = DatabaseConnection.getConnection();
		         PreparedStatement stmt = conn.prepareStatement(sql)) {

		        stmt.setString(1, username);
		        stmt.setString(2, email);
		        stmt.setString(3, phone);
		        stmt.setString(4, password);
		        stmt.setString(5, role);
		        stmt.setBoolean(6, status);
		        stmt.setString(7, firstName);
		        stmt.setString(8, lastName);
		        stmt.setString(9, address);
		        stmt.setInt(10, userId);

		        stmt.executeUpdate();
		        System.out.println("User updated successfully!");
		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		}

	public static void updateUser(int userId, String username, String email, String phone, String password, String role, boolean status) {
	    String sql = "UPDATE users SET username=?, email=?, phone_number=?, password=?, role=?, status=? WHERE user_id=?";
	
	    try (Connection conn = DatabaseConnection.getConnection();
	         PreparedStatement stmt = conn.prepareStatement(sql)) {
	
	        stmt.setString(1, username);
	        stmt.setString(2, email);
	        stmt.setString(3, phone);
	        stmt.setString(4, password);
	        stmt.setString(5, role);
	        stmt.setBoolean(6, status);
	        stmt.setInt(7, userId);
	
	        stmt.executeUpdate();
	        System.out.println("User updated successfully!");
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	
	public static void deleteUser(int userId) {
	    String sql = "DELETE FROM users WHERE user_id=?";
	
	    try (Connection conn = DatabaseConnection.getConnection();
	         PreparedStatement stmt = conn.prepareStatement(sql)) {
	
	        stmt.setInt(1, userId);
	        stmt.executeUpdate();
	        System.out.println("User deleted successfully!");
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
}
