package controller;

import dao.MovieDAO;
import dao.RentalDAO;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Movie;
import model.Rental;

import java.util.List;

public class RentalController {

	@FXML private TableView<Movie> movieTable; //Ensure this is declared
    @FXML private TableView<Rental> rentalTable;
    @FXML private TableColumn<Rental, String> movieTitleColumn;
    @FXML private TableColumn<Rental, String> rentalDateColumn;
    @FXML private TableColumn<Rental, String> dueDateColumn;
    @FXML private TableColumn<Rental, String> statusColumn;
    @FXML private TableColumn<Rental, Void> returnColumn;
    private int userId; // This will be set when loading the rental view
    private String userRole; // To check access
    
    public void setUserRole(String role) {
        this.userRole = role;
    }


    @FXML
    public void initialize() {
        movieTitleColumn.setCellValueFactory(new PropertyValueFactory<>("movieTitle"));
        rentalDateColumn.setCellValueFactory(new PropertyValueFactory<>("rentalDate"));
        dueDateColumn.setCellValueFactory(new PropertyValueFactory<>("dueDate"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));

        returnColumn.setCellFactory(param -> new TableCell<>() {
            private final Button returnButton = new Button("Return");

            {
                returnButton.setOnAction(event -> {
                    Rental rental = getTableView().getItems().get(getIndex());
                    handleReturn(rental);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(returnButton);
                }
            }
        });

        loadRentals();
    }

    private void loadRentals() {
        List<Rental> rentals = RentalDAO.getAllRentals();
        rentalTable.setItems(FXCollections.observableArrayList(rentals));
    }

    private void handleReturn(Rental rental) {
        RentalDAO.returnRental(rental.getRentalId());
        loadRentals(); // Refresh the table
    }

    @FXML
    private void handleBack() {
        rentalTable.getScene().getWindow().hide();
    }
    
    private void loadMovies() {
        List<Movie> movies = MovieDAO.getAvailableMovies();
        movieTable.setItems(FXCollections.observableArrayList(movies));
    }

    public void setUserInfo(int userId, String userRole) {
        this.userId = userId;
        this.userRole = userRole;
    }

    private void handleRent(Movie selectedMovie) {
        if (!"customer".equals(userRole)) {
            System.err.println("Only customers can rent movies!");
            return;
        }

        if (selectedMovie == null) {
            System.err.println("Please select a movie.");
            return;
        }

        RentalDAO.insertRental(userId, selectedMovie.getMovieId());
        loadMovies(); // Refresh the movie list
    }
}
