package controller;

import dao.MovieDAO;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.Movie;

public class UpdateMovieController {

    @FXML private TextField titleField, directorField, actorField;
    @FXML private ComboBox<String> genreField;
    @FXML private TextArea descriptionField;
    @FXML private DatePicker releaseDatePicker;
    private Movie selectedMovie;

    public void setMovieData(Movie movie) {
        this.selectedMovie = movie;
        titleField.setText(movie.getTitle());
        genreField.setValue(movie.getGenre());
        directorField.setText(movie.getDirector());
        actorField.setText(movie.getActor());
        descriptionField.setText(movie.getDescription());
        releaseDatePicker.setValue(java.time.LocalDate.parse(movie.getReleaseDate()));
    }

    @FXML
    private void initialize() {
        genreField.setItems(FXCollections.observableArrayList(
                "Action", "Comedy", "Drama", "Horror", "Sci-Fi",
                "Romance", "Thriller", "Fantasy", "Adventure", "Animation"
        ));
    }

    @FXML
    private void handleSave() {
        if (selectedMovie == null) {
            System.err.println("No movie selected!");
            return;
        }

        String title = titleField.getText();
        String genre = genreField.getValue();
        String director = directorField.getText();
        String actor = actorField.getText();
        String description = descriptionField.getText();
        String releaseDate = (releaseDatePicker.getValue() != null) ? releaseDatePicker.getValue().toString() : null;

        if (title.isEmpty() || genre == null || director.isEmpty() || actor.isEmpty() || description.isEmpty() || releaseDate == null) {
            System.err.println("All fields are required!");
            return;
        }

        MovieDAO.updateMovie(selectedMovie.getMovieId(), title, genre, director, actor, description, releaseDate);
        System.out.println("Movie updated: " + title);

        Stage stage = (Stage) titleField.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void handleCancel() {
        Stage stage = (Stage) titleField.getScene().getWindow();
        stage.close();
    }
}
