package controller;

import dao.MovieDAO;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Movie;

import java.io.IOException;
import java.util.List;

public class MovieController {

    @FXML private TableView<Movie> movieTable;
    @FXML private TableColumn<Movie, String> titleColumn;
    @FXML private TableColumn<Movie, String> genreColumn;
    @FXML private TextField titleField;
    @FXML private TextField genreField;
    @FXML private TextField directorField;
    @FXML private TextField actorField;
    @FXML private TextField descriptionField;
    @FXML private DatePicker releaseDatePicker;
    @FXML private TableColumn<Movie, String> releaseDateColumn;
    
    private ObservableList<Movie> movieList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        genreColumn.setCellValueFactory(new PropertyValueFactory<>("genre"));
        releaseDateColumn.setCellValueFactory(new PropertyValueFactory<>("releaseDate"));
        loadMovies();
        
        // Add double-click event listener to the TableView
        movieTable.setRowFactory(tv -> {
            TableRow<Movie> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2 && (!row.isEmpty())) { // Double-click detected
                    Movie selectedMovie = row.getItem();
                    openUpdateMovieForm(selectedMovie);
                }
            });
            return row;
        });
    }

    private void loadMovies() {
        movieList.clear();
        List<Movie> movies = MovieDAO.getAllMovies();
        movieList.addAll(movies);
        movieTable.setItems(movieList);
    }

    @FXML
    private void handleAddMovie() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/ui/AddMovieView.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle("Add New Movie");
            stage.setScene(new Scene(root, 400, 500));
            stage.showAndWait(); 

            loadMovies();  // Refresh movie list after adding
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @FXML
    private void handleUpdateMovie() {
        System.out.println("Update Movie button clicked!");
        // TODO: Implement update movie logic
        //button to be removed.
    }

    private void openUpdateMovieForm(Movie selectedMovie) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/ui/UpdateMovieView.fxml"));
            Parent root = loader.load();

            UpdateMovieController controller = loader.getController();
            controller.setMovieData(selectedMovie); // Pass selected movie data

            Stage stage = new Stage();
            stage.setTitle("Update Movie");
            stage.setScene(new Scene(root, 400, 500));
            stage.showAndWait();  // Wait for the form to close

            loadMovies();  // Refresh movie list after updating
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //deletes a movie record selected
    @FXML
    private void handleDeleteMovie() {
        Movie selectedMovie = movieTable.getSelectionModel().getSelectedItem();
        if (selectedMovie != null) {
            MovieDAO.deleteMovie(selectedMovie.getMovieId());
            loadMovies();
        }
    }
    
    //goes back to the previous UI
    @FXML
    private void handleBack() throws IOException {
        Stage stage = (Stage) movieTable.getScene().getWindow();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/ui/MainView.fxml"));
        Scene scene = new Scene(loader.load());
        stage.setScene(scene);
    }
}
