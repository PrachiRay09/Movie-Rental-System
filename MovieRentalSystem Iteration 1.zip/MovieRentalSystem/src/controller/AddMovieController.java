package controller;

import dao.MovieDAO;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class AddMovieController {

    @FXML
    private TextField titleField, directorField, actorField;
    @FXML
    private ComboBox<String> genreField; // ComboBox for genres
    @FXML
    private TextArea descriptionField;
    @FXML
    private DatePicker releaseDatePicker;

    @FXML
    private void initialize() {
        // Populate the ComboBox dynamically in the controller
        genreField.setItems(FXCollections.observableArrayList(
                "Action", "Comedy", "Drama", "Horror", "Sci-Fi",
                "Romance", "Thriller", "Fantasy", "Adventure", "Animation"
        ));
    }

    //save record to movie table
    @FXML
    private void handleSave() {
        String title = titleField.getText();
        String genre = genreField.getValue();
        String director = directorField.getText();
        String actor = actorField.getText();
        String description = descriptionField.getText();
        String releaseDate = (releaseDatePicker.getValue() != null) ? releaseDatePicker.getValue().toString() : null;

        if (title.isEmpty() || genre == null || director.isEmpty() || actor.isEmpty() || description.isEmpty() || releaseDate == null) {
            System.err.println("All fields are required!");
            return;
        }

        // Insert into database
        MovieDAO.insertMovie(title, genre, director, actor, description, releaseDate);
        System.out.println("Movie added: " + title);

        // Close the pop-up window
        Stage stage = (Stage) titleField.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void handleCancel() {
        // Close the pop-up window
        Stage stage = (Stage) titleField.getScene().getWindow();
        stage.close();
    }
}
