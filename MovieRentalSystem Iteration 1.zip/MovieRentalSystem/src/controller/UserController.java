package controller;

import dao.UserDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.User;
import javafx.beans.property.SimpleStringProperty;

import java.io.IOException;
import java.util.List;

public class UserController {

    @FXML private TableView<User> userTable;
    @FXML private TableColumn<User, String> usernameColumn;
    @FXML private TableColumn<User, String> emailColumn;
    @FXML private TableColumn<User, String> roleColumn;
    @FXML private TableColumn<User, String> statusColumn;
    @FXML private TableColumn<User, String> firstNameColumn;
    @FXML private TableColumn<User, String> lastNameColumn;
    @FXML private TableColumn<User, String> phoneNumberColumn;
    @FXML private TableColumn<User, String> addressColumn;
    @FXML private Button btnAddUser, btnDeleteUser;

    private ObservableList<User> userList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        usernameColumn.setCellValueFactory(cellData -> cellData.getValue().usernameProperty());
        emailColumn.setCellValueFactory(cellData -> cellData.getValue().emailProperty());
        roleColumn.setCellValueFactory(cellData -> cellData.getValue().roleProperty());
        firstNameColumn.setCellValueFactory(cellData -> cellData.getValue().firstNameProperty());
        lastNameColumn.setCellValueFactory(cellData -> cellData.getValue().lastNameProperty());
        phoneNumberColumn.setCellValueFactory(cellData -> cellData.getValue().phoneNumberProperty());
        addressColumn.setCellValueFactory(cellData -> cellData.getValue().addressProperty());

        // Convert boolean status to a string ("Active" or "Inactive")
        statusColumn.setCellValueFactory(cellData -> 
            new SimpleStringProperty(cellData.getValue().isStatus() ? "Active" : "Inactive")
        );

        loadUsers();

        // Double-click to edit user
        userTable.setRowFactory(tv -> {
            TableRow<User> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2 && (!row.isEmpty())) {
                    User selectedUser = row.getItem();
                    openEditUserForm(selectedUser);
                }
            });
            return row;
        });
    }

    private void loadUsers() {
        userList.clear();
        List<User> users = UserDAO.getAllUsers();
        userList.addAll(users);
        userTable.setItems(userList);
    }

    @FXML
    private void handleAddUser() {
        openUserForm(null); // Open form with no user for adding
    }
    
    @FXML
    private void handleDeleteUser() {
        User selectedUser = userTable.getSelectionModel().getSelectedItem();
        if (selectedUser != null) {
            UserDAO.deleteUser(selectedUser.getUserId());
            loadUsers();
        }
    }

    private void openEditUserForm(User selectedUser) {
        openUserForm(selectedUser);
    }

    private void openUserForm(User user) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/ui/UserForm.fxml"));
            Parent root = loader.load();

            UserFormController controller = loader.getController();
            if (user != null) {
                controller.setUserData(user);
            }

            Stage stage = new Stage();
            stage.setTitle(user == null ? "Add User" : "Edit User");
            stage.setScene(new Scene(root, 400, 500));
            stage.showAndWait();

            loadUsers();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleBack() throws IOException {
        Stage stage = (Stage) userTable.getScene().getWindow();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/ui/MainView.fxml"));
        Scene scene = new Scene(loader.load());
        stage.setScene(scene);
    }
}
