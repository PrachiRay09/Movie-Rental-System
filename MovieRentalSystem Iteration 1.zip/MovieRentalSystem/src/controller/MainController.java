package controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Tab;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;

public class MainController {

    @FXML    private VBox userTabContent;
    @FXML    private VBox movieTabContent;
    @FXML	 private VBox rentalTabContent;
    @FXML    private Tab rentalTab, usersTab, moviesTab;
    
    private String userRole;
    
    public void setUserRole(String role) {
        this.userRole = role;
        checkAccess();
    }

    private void checkAccess() {
        if (!userRole.equals("customer")) {
            rentalTab.setDisable(true); // Disable Rentals tab for non-customers
        }
    }
    
    @FXML
    public void initialize() {
        System.out.println("Initializing Main Controller...");
        loadUserView();
        loadMovieView();
    }

    private void loadUserView() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/ui/UserView.fxml"));
            VBox view = loader.load();
            userTabContent.getChildren().setAll(view);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadMovieView() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/ui/MovieView.fxml"));
            VBox view = loader.load();
            movieTabContent.getChildren().setAll(view);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @FXML
    private void openRentalModule() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/ui/RentalView.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle("Manage Rentals");
            stage.setScene(new Scene(root, 600, 400));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
