package controller;

import dao.UserDAO;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.User;

public class UserFormController {

    @FXML private TextField usernameField, emailField, firstNameField, lastNameField, phoneField;
    @FXML private PasswordField passwordField;
    @FXML private ComboBox<String> roleField;
    @FXML private TextArea addressField;
    @FXML private CheckBox statusField;

    private User selectedUser;

    @FXML
    private void initialize() {
        roleField.setItems(FXCollections.observableArrayList("admin", "staff", "customer"));
    }

    public void setUserData(User user) {
        this.selectedUser = user;
        usernameField.setText(user.getUsername());
        emailField.setText(user.getEmail());
        passwordField.setText(""); // Password should be re-entered for security
        firstNameField.setText(user.getFirstName());
        lastNameField.setText(user.getLastName());
        phoneField.setText(user.getPhoneNumber());
        roleField.setValue(user.getRole());
        addressField.setText(user.getAddress());
        statusField.setSelected(user.isStatus());
    }

    @FXML
    private void handleSave() {
        String username = usernameField.getText();
        String email = emailField.getText();
        String password = passwordField.getText();
        String firstName = firstNameField.getText();
        String lastName = lastNameField.getText();
        String phone = phoneField.getText();
        String role = roleField.getValue();
        String address = addressField.getText() == null ? "" : addressField.getText().trim();
        boolean status = statusField.isSelected();

        if (username.isEmpty() || email.isEmpty() || password.isEmpty() || firstName.isEmpty() || lastName.isEmpty() || phone.isEmpty() || role == null) {
            System.err.println("All fields except address are required!");
            return;
        }

        if (selectedUser == null) {
            UserDAO.insertUser(username, email, phone, password, role, status, firstName, lastName, address);
        } else {
            UserDAO.updateUser(selectedUser.getUserId(), username, email, phone, password, role, status, firstName, lastName, address);
        }

        Stage stage = (Stage) usernameField.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void handleCancel() {
        Stage stage = (Stage) usernameField.getScene().getWindow();
        stage.close();
    }
}
