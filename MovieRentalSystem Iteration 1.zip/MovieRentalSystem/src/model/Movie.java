package model;

public class Movie {
    private int movieId;
    private String title;
    private String genre;
    private String releaseDate;
    private String actor;
    private String director;
    private String description;

    public Movie(int movieId, String title, String genre, String releaseDate, String actor, String director, String description) {
        this.movieId = movieId;
        this.title = title;
        this.genre = genre;
        this.releaseDate = releaseDate;
        this.actor = actor;
        this.director = director;
        this.description = description;
    }

    // Getters and Setters
    public int getMovieId() { return movieId; }
    public void setMovieId(int movieId) { this.movieId = movieId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getGenre() { return genre; }
    public void setGenre(String genre) { this.genre = genre; }

    public String getReleaseDate() { return releaseDate; }
    public void setReleaseDate(String releaseDate) { this.releaseDate = releaseDate; }

    public String getActor() { return actor; }
    public void setActor(String actor) { this.actor = actor; }

    public String getDirector() { return director; }
    public void setDirector(String director) { this.director = director; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}
