package model;

import java.time.LocalDate;

public class Rental {
    private int rentalId;
    private String movieTitle; // This will be fetched from the movies table
    private LocalDate rentalDate;
    private LocalDate dueDate;
    private String status;

    public Rental(int rentalId, String movieTitle, LocalDate rentalDate, LocalDate dueDate, String status) {
        this.rentalId = rentalId;
        this.movieTitle = movieTitle;
        this.rentalDate = rentalDate;
        this.dueDate = dueDate;
        this.status = status;
    }

    public int getRentalId() {
        return rentalId;
    }

    public String getMovieTitle() {
        return movieTitle;
    }

    public LocalDate getRentalDate() {
        return rentalDate;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public String getStatus() {
        return status;
    }
}
