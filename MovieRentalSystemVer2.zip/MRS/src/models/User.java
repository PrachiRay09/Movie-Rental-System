package models;

public class User {
    private int userId;
    private String username;
    private String email;
    private String role;
    private boolean status;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String address;
    private String password;

    public User(int userId, String username, String password, String email, String role, boolean status,
                String firstName, String lastName, String phoneNumber, String address) {
        this.userId = userId;
        this.username = username;
        this.email = email;
        this.password = password;
        this.role = role;
        this.status = status;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.address = address;
    }

    public int getUserId() {
        return userId;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }
    
    public String getPassword() {
    	return password;
    }

    public String getRole() {
        return role;
    }

    public boolean isStatus() {
        return status;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getAddress() {
        return address;
    }
}
