package models;

import java.time.LocalDate;

public class RentedMovie {
    private String title;
    private String genre;
    private LocalDate dueDate;

    public RentedMovie(String title, String genre, LocalDate dueDate) {
        this.title = title;
        this.genre = genre;
        this.dueDate = dueDate;
    }

    public String getTitle() {
        return title;
    }

    public String getGenre() {
        return genre;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }
}
