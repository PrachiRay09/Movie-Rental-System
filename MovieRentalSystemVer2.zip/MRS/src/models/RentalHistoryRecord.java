package models;

import java.time.LocalDate;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;

public class RentalHistoryRecord {
	private final StringProperty title;
	private final ObjectProperty<LocalDate> rentalDate;
	private final ObjectProperty<LocalDate> dueDate;
	private final ObjectProperty<LocalDate> returnDate;
	private final StringProperty status;
	private final DoubleProperty lateFee;
	private final IntegerProperty rating;
	private final IntegerProperty movieId;
	private final IntegerProperty userId;
    //private int rating;
    //private SimpleIntegerProperty rating = new SimpleIntegerProperty(0); // Default 0

    public RentalHistoryRecord(String title, LocalDate rentalDate, LocalDate dueDate,
                               LocalDate returnDate, String status, double lateFee, int rating, int movieId, int userId) {
		/*
		 * this.title = title; this.rentalDate = rentalDate; this.dueDate = dueDate;
		 * this.returnDate = returnDate; this.status = status; this.lateFee = lateFee;
		 * this.rating.set(rating);
		 */
        this.title = new SimpleStringProperty(title);
        this.rentalDate = new SimpleObjectProperty<>(rentalDate);
        this.dueDate = new SimpleObjectProperty<>(dueDate);
        this.returnDate = new SimpleObjectProperty<>(returnDate);
        this.status = new SimpleStringProperty(status);
        this.lateFee = new SimpleDoubleProperty(lateFee);
        this.rating = new SimpleIntegerProperty(rating);
        this.movieId = new SimpleIntegerProperty(movieId);
        this.userId = new SimpleIntegerProperty(userId);
    }
    public String getTitle() { return title.get(); }
    public StringProperty titleProperty() { return title; }

    public LocalDate getRentalDate() { return rentalDate.get(); }
    public ObjectProperty<LocalDate> rentalDateProperty() { return rentalDate; }

    public LocalDate getDueDate() { return dueDate.get(); }
    public ObjectProperty<LocalDate> dueDateProperty() { return dueDate; }

    public LocalDate getReturnDate() { return returnDate.get(); }
    public ObjectProperty<LocalDate> returnDateProperty() { return returnDate; }

    public String getStatus() { return status.get(); }
    public StringProperty statusProperty() { return status; }

    public double getLateFee() { return lateFee.get(); }
    public DoubleProperty lateFeeProperty() { return lateFee; }

    public int getRating() { return rating.get(); }
    public IntegerProperty ratingProperty() { return rating; }
    
    public void setRating(int rating) {
        this.rating.set(rating);
    }
    
    public int getMovieId() {
        return movieId.get();
    }
    public int getUserId() {
        return userId.get();
    }
}
