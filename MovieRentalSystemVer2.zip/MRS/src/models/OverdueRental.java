package models;

public class OverdueRental {
    private String movieTitle;
    private String customerUsername;
    private String dueDate;
    private int daysOverdue;

    public OverdueRental(String movieTitle, String customerUsername, String dueDate, int daysOverdue) {
        this.movieTitle = movieTitle;
        this.customerUsername = customerUsername;
        this.dueDate = dueDate;
        this.daysOverdue = daysOverdue;
    }

    public String getMovieTitle() {
        return movieTitle;
    }

    public String getCustomerUsername() {
        return customerUsername;
    }

    public String getDueDate() {
        return dueDate;
    }

    public int getDaysOverdue() {
        return daysOverdue;
    }
}
