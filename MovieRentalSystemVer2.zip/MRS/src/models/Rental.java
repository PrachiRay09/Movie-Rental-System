package models;

import javafx.beans.property.*;

public class Rental {
    private final StringProperty user;
    private final StringProperty movie;
    private final StringProperty rentalDate;
    private final StringProperty dueDate;
    private final StringProperty status;

    public Rental(String user, String movie, String rentalDate, String dueDate, String status) {
        this.user = new SimpleStringProperty(user);
        this.movie = new SimpleStringProperty(movie);
        this.rentalDate = new SimpleStringProperty(rentalDate);
        this.dueDate = new SimpleStringProperty(dueDate);
        this.status = new SimpleStringProperty(status);
    }

    public String getUser() {
        return user.get();
    }

    public void setUser(String value) {
        user.set(value);
    }

    public StringProperty userProperty() {
        return user;
    }

    public String getMovie() {
        return movie.get();
    }

    public void setMovie(String value) {
        movie.set(value);
    }

    public StringProperty movieProperty() {
        return movie;
    }

    public String getRentalDate() {
        return rentalDate.get();
    }

    public void setRentalDate(String value) {
        rentalDate.set(value);
    }

    public StringProperty rentalDateProperty() {
        return rentalDate;
    }

    public String getDueDate() {
        return dueDate.get();
    }

    public void setDueDate(String value) {
        dueDate.set(value);
    }

    public StringProperty dueDateProperty() {
        return dueDate;
    }

    public String getStatus() {
        return status.get();
    }

    public void setStatus(String value) {
        status.set(value);
    }

    public StringProperty statusProperty() {
        return status;
    }
}
