package controllers;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.cell.PropertyValueFactory;
import models.Movie;
import utils.DatabaseConnector;

import java.sql.*;
import java.time.LocalDate;
import java.util.stream.Collectors;

public class RentalController {

    @FXML private TableView<Movie> movieTable;
    @FXML private TableColumn<Movie, String> titleColumn;
    @FXML private TableColumn<Movie, String> genreColumn;
    @FXML private TableColumn<Movie, String> statusColumn;

    @FXML private TextField searchField;
    @FXML private ComboBox<String> genreFilterComboBox;
    @FXML private TextField customerUsernameField;
    @FXML private Button rentButton;
    @FXML private Button returnButton;
    @FXML private Button notifyButton;

    private final ObservableList<Movie> masterMovieList = FXCollections.observableArrayList();
    private final ObservableList<Movie> filteredMovieList = FXCollections.observableArrayList();

    public void initialize() {
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        genreColumn.setCellValueFactory(new PropertyValueFactory<>("genre"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));

        genreFilterComboBox.setItems(FXCollections.observableArrayList("All", "Action", "Drama", "Comedy", "Horror", "Thriller", "Sci-Fi"));
        genreFilterComboBox.setValue("All");

        movieTable.setItems(filteredMovieList);

        searchField.textProperty().addListener((obs, oldVal, newVal) -> filterMovies());
        genreFilterComboBox.setOnAction(e -> filterMovies());

        rentButton.setOnAction(e -> rentMovie());
        returnButton.setOnAction(e -> returnMovie());
        notifyButton.setOnAction(e -> notifyCustomer());

        loadMovies();
    }

    private void loadMovies() {
        masterMovieList.clear();
        String query = "SELECT m.movie_id, m.title, m.genre, r.status FROM movies m " +
                       "LEFT JOIN rentals r ON m.movie_id = r.movie_id AND r.return_date IS NULL";

        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                String status = rs.getString("status");
                if (status == null) status = "Available";
                masterMovieList.add(new Movie(
                    rs.getInt("movie_id"),
                    rs.getString("title"),
                    rs.getString("genre"),
                    status
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        filterMovies();
    }

    private void filterMovies() {
        String search = searchField.getText().toLowerCase();
        String genreFilter = genreFilterComboBox.getValue();

        filteredMovieList.setAll(masterMovieList.stream().filter(movie -> {
            boolean matchesSearch = search.isEmpty() || movie.getTitle().toLowerCase().contains(search);
            boolean matchesGenre = genreFilter.equals("All") || movie.getGenre().equalsIgnoreCase(genreFilter);
            return matchesSearch && matchesGenre;
        }).collect(Collectors.toList()));
    }

    private void rentMovie() {
        Movie selected = movieTable.getSelectionModel().getSelectedItem();
        String username = customerUsernameField.getText().trim();

        if (selected == null || username.isEmpty()) return;

        try (Connection conn = DatabaseConnector.getConnection()) {
            PreparedStatement userStmt = conn.prepareStatement("SELECT user_id FROM users WHERE username = ?");
            userStmt.setString(1, username);
            ResultSet userRs = userStmt.executeQuery();
            if (!userRs.next()) return;

            int userId = userRs.getInt("user_id");

            PreparedStatement rentStmt = conn.prepareStatement(
                "INSERT INTO rentals (user_id, movie_id, rental_date, due_date, status, late_fee) VALUES (?, ?, CURRENT_DATE, CURRENT_DATE + INTERVAL '7 day', 'rented', 0)");
            rentStmt.setInt(1, userId);
            rentStmt.setInt(2, selected.getMovieId());
            rentStmt.executeUpdate();

            loadMovies();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void returnMovie() {
        Movie selected = movieTable.getSelectionModel().getSelectedItem();
        if (selected == null) return;

        try (Connection conn = DatabaseConnector.getConnection()) {
            PreparedStatement stmt = conn.prepareStatement(
                "UPDATE rentals SET return_date = CURRENT_DATE, status = 'returned' WHERE movie_id = ? AND return_date IS NULL");
            stmt.setInt(1, selected.getMovieId());
            stmt.executeUpdate();
            loadMovies();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void notifyCustomer() {
        // Future implementation: Email overdue notifications
        System.out.println("Overdue notifications feature pending implementation.");
    }
}
