package controllers;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import application.MainApp;
import utils.DatabaseConnector;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.regex.Pattern;

public class RegisterController {

    @FXML
    private TextField usernameField, emailField, firstNameField, lastNameField, phoneNumberField, addressField;
    @FXML
    private PasswordField passwordField, confirmPasswordField;
    @FXML
    private ComboBox<String> roleComboBox;
    @FXML
    private Button registerButton;
    @FXML
    private Label errorLabel;

    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[A-Za-z0-9+_.-]+@(.+)$");
    private static final Pattern PHONE_PATTERN = Pattern.compile("^\\d{10,15}$");

    @FXML
    public void initialize() {

    	    roleComboBox.getItems().add("customer");
    	    roleComboBox.setValue("customer");       // Pre-select
    	    roleComboBox.setDisable(true);           // Optional: make it read-only
    	    registerButton.setOnAction(e -> registerUser());


        phoneNumberField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (!newVal.matches("\\d*")) {
                phoneNumberField.setText(newVal.replaceAll("[^\\d]", ""));
            } else if (newVal.length() > 15) {
                phoneNumberField.setText(newVal.substring(0, 15));
            }
        });

        emailField.focusedProperty().addListener((obs, wasFocused, isNowFocused) -> {
            if (!isNowFocused) {
                String email = emailField.getText().trim();
                if (!EMAIL_PATTERN.matcher(email).matches()) {
                    showError("Invalid email format.");
                } else {
                    errorLabel.setVisible(false);
                }
            }
        });
    }
   

    private void registerUser() {
        String username = usernameField.getText().trim();
        String email = emailField.getText().trim();
        String password = passwordField.getText();
        String confirmPassword = confirmPasswordField.getText();
        String role = roleComboBox.getValue();
        String firstName = firstNameField.getText().trim();
        String lastName = lastNameField.getText().trim();
        String phone = phoneNumberField.getText().trim();
        String address = addressField.getText().trim();

        // Validate mandatory fields
        if (firstName.isEmpty() || lastName.isEmpty() || phone.isEmpty() || address.isEmpty() ||
            username.isEmpty() || email.isEmpty() || password.isEmpty() || role == null || confirmPassword.isEmpty()) {
            showError("All fields are required.");
            return;
        }

        // Validate password match
        if (!password.equals(confirmPassword)) {
            showError("Passwords do not match.");
            return;
        }

        // Validate email format
        if (!EMAIL_PATTERN.matcher(email).matches()) {
            showError("Invalid email format.");
            return;
        }

        // Validate phone number format
        if (!PHONE_PATTERN.matcher(phone).matches()) {
            showError("Phone number must be 10 to 15 digits.");
            return;
        }

        String query = "INSERT INTO users (username, email, password, role, status, first_name, last_name, phone_number, address) " +
                       "VALUES (?, ?, ?, ?, true, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, username);
            stmt.setString(2, email);
            stmt.setString(3, password);
            stmt.setString(4, role);
            stmt.setString(5, firstName);
            stmt.setString(6, lastName);
            stmt.setString(7, phone);
            stmt.setString(8, address);
            stmt.executeUpdate();

            showSuccess("Registration successful! Redirecting to login...");
            Thread.sleep(1500);
            MainApp.showLoginScreen();
        } catch (SQLException e) {
            showError("Registration failed. Username, email, or phone number may already exist.");
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void showError(String message) {
        errorLabel.setText(message);
        errorLabel.setStyle("-fx-text-fill: red;");
        errorLabel.setVisible(true);
    }

    private void showSuccess(String message) {
        errorLabel.setText(message);
        errorLabel.setStyle("-fx-text-fill: green;");
        errorLabel.setVisible(true);
    }
}
