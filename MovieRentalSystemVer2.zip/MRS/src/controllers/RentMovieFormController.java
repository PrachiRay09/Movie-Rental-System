package controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.stage.Modality;
import javafx.stage.Stage;
import models.Movie;
import utils.DatabaseConnector;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

public class RentMovieFormController {

    @FXML private Label titleLabel;
    @FXML private Label genreLabel;
    @FXML private Label dueDateLabel;

    private Movie movie;
    private int userId;

    public void setData(Movie movie, int userId) {
        this.movie = movie;
        this.userId = userId;

        titleLabel.setText(movie.getTitle());
        genreLabel.setText(movie.getGenre());

        LocalDate dueDate = LocalDate.now().plusDays(7);
        dueDateLabel.setText(dueDate.toString());
    }

    @FXML
    private void handleConfirmRental() {
        String sql = "INSERT INTO rentals (user_id, movie_id, rental_date, due_date, status, late_fee) VALUES (?, ?, CURRENT_DATE, CURRENT_DATE + INTERVAL '7 days', 'rented', 0)";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.setInt(2, movie.getMovieId());
            stmt.executeUpdate();
            ((Stage) titleLabel.getScene().getWindow()).close(); // Close dialog
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
 }
