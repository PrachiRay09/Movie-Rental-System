package controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import models.Movie;
import utils.DatabaseConnector;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class RentSummaryDialogController {

    @FXML private VBox movieListVBox;
    @FXML private Label dueDateLabel;
    @FXML private Label subtotalLabel;
    @FXML private Label taxLabel;
    @FXML private Label totalLabel;
    //@FXML private Label paymentMethodLabel;
    @FXML private Label amountPaidLabel;
    @FXML private ComboBox<String> paymentMethodComboBox;

    private List<Movie> selectedMovies;
    private int currentUserId;
    private static final double PRICE_PER_MOVIE = 5.00;
    private static final double TAX_RATE = 0.15;

    public static void openDialog(List<Movie> movies, int userId) {
        try {
            FXMLLoader loader = new FXMLLoader(RentSummaryDialogController.class.getResource("/ui/RentSummaryDialog.fxml"));
            Parent root = loader.load();

            RentSummaryDialogController controller = loader.getController();
            controller.setMovies(movies, userId);

            Stage stage = new Stage();
            stage.setTitle("Confirm Rental");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setMovies(List<Movie> movies, int userId) {
        this.selectedMovies = movies;
        this.currentUserId = userId;

        LocalDate dueDate = LocalDate.now().plusDays(7);
        dueDateLabel.setText("Due Date: " + dueDate);

        for (Movie movie : selectedMovies) {
            Label movieLabel = new Label("• " + movie.getTitle() + " (" + movie.getGenre() + ")");
            movieListVBox.getChildren().add(movieLabel);
        }

        paymentMethodComboBox.getItems().addAll("cash", "credit_card", "debit_card", "paypal");
        paymentMethodComboBox.getSelectionModel().selectFirst();

        calculateAndDisplayPrices();
    }

    private void calculateAndDisplayPrices() {
        double subtotal = selectedMovies.size() * PRICE_PER_MOVIE;
        double tax = subtotal * TAX_RATE;
        double total = subtotal + tax;

        subtotalLabel.setText("Subtotal: $" + String.format("%.2f", subtotal));
        taxLabel.setText("Tax (15%): $" + String.format("%.2f", tax));
        totalLabel.setText("Total: $" + String.format("%.2f", total));
        amountPaidLabel.setText("Amount Paid: $" + String.format("%.2f", total));
       // paymentMethodLabel.setText("Payment Method: " + paymentMethodComboBox.getSelectionModel().getSelectedItem());
    }

    @FXML
    private void handleConfirmRental() {
        String rentalSql = "INSERT INTO rentals (user_id, movie_id, rental_date, due_date, status, late_fee) VALUES (?, ?, CURRENT_DATE, CURRENT_DATE + INTERVAL '7 days', 'rented', 0)";
        String paymentSql = "INSERT INTO payments (rental_id, amount_paid, payment_date, payment_method, transaction_status) VALUES (?, ?, CURRENT_DATE, ?, 'Completed')";

        double subtotal = selectedMovies.size() * PRICE_PER_MOVIE;
        double tax = subtotal * TAX_RATE;
        double total = subtotal + tax;
        String paymentMethod = paymentMethodComboBox.getSelectionModel().getSelectedItem();

        try (Connection conn = DatabaseConnector.getConnection()) {
            conn.setAutoCommit(false);

            try (PreparedStatement rentalStmt = conn.prepareStatement(rentalSql, Statement.RETURN_GENERATED_KEYS);
                 PreparedStatement paymentStmt = conn.prepareStatement(paymentSql)) {

                List<Integer> rentalIds = new ArrayList<>();

                for (Movie movie : selectedMovies) {
                    rentalStmt.setInt(1, currentUserId);
                    rentalStmt.setInt(2, movie.getMovieId());
                    rentalStmt.executeUpdate();

                    try (ResultSet rs = rentalStmt.getGeneratedKeys()) {
                        if (rs.next()) {
                            rentalIds.add(rs.getInt(1));
                        }
                    }
                }

                for (Integer rentalId : rentalIds) {
                    paymentStmt.setInt(1, rentalId);
                    paymentStmt.setBigDecimal(2, new BigDecimal(total).setScale(2, RoundingMode.HALF_UP));
                    paymentStmt.setString(3, paymentMethod);
                    paymentStmt.addBatch();
                }

                paymentStmt.executeBatch();
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                e.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        ((Stage) movieListVBox.getScene().getWindow()).close();
    }

    @FXML
    private void handleCancel() {
        ((Stage) movieListVBox.getScene().getWindow()).close();
    }
}