package controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.layout.HBox;
import models.Movie;
import models.RentalHistoryRecord;
import models.RentedMovie;
import models.TopRatedMovie;
import models.User;
import utils.DatabaseConnector;
import java.time.LocalDate;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CustomerDashboardController {

    @FXML private Label welcomeLabel;
    @FXML private Label welcomeLabelAva;
    @FXML private Label totalRentedLabel;
    @FXML private Label currentlyRentedLabel;
    @FXML private Label overdueMoviesLabel;
    @FXML private Label lateFeesLabel;

    @FXML private TableView<Movie> availableMoviesTable;
    @FXML private TableColumn<Movie, String> availableTitleColumn;
    @FXML private TableColumn<Movie, String> availableGenreColumn;
    @FXML private TableColumn<Movie, String> availableStatusColumn;
    @FXML private TableColumn<Movie, String> availableReleaseDateColumn;
    @FXML private TableColumn<Movie, String> availableActorColumn;
    @FXML private TableColumn<Movie, String> availableDirectorColumn;
    private final ObservableList<Movie> availableMovies = FXCollections.observableArrayList();
    private String name;
    
    @FXML private TableView<RentedMovie> rentedMoviesTable;
    @FXML private TableColumn<RentedMovie, String> rentedTitleColumn;
    @FXML private TableColumn<RentedMovie, String> rentedGenreColumn;
    @FXML private TableColumn<RentedMovie, LocalDate> rentedDueDateColumn;
    private final ObservableList<RentedMovie> rentedMovies = FXCollections.observableArrayList();

    @FXML private TableView<RentalHistoryRecord> rentalHistoryTable;
    @FXML private TableColumn<RentalHistoryRecord, String> historyTitleColumn;
    @FXML private TableColumn<RentalHistoryRecord, LocalDate> historyRentalDateColumn;
    @FXML private TableColumn<RentalHistoryRecord, LocalDate> historyDueDateColumn;
    @FXML private TableColumn<RentalHistoryRecord, LocalDate> historyReturnDateColumn;
    @FXML private TableColumn<RentalHistoryRecord, String> historyStatusColumn;
    @FXML private TableColumn<RentalHistoryRecord, Double> historyLateFeeColumn;
    @FXML private TableColumn<RentalHistoryRecord, Integer> historyRatingColumn;
    private final ObservableList<RentalHistoryRecord> rentalHistory = FXCollections.observableArrayList();

    @FXML private TextField firstNameField;
    @FXML private TextField lastNameField;
    @FXML private TextField usernameField;
    @FXML private TextField emailField;
    @FXML private TextField passwordField;
    @FXML private TextField phoneField;
    @FXML private TextField addressField;
    @FXML private Button saveProfileButton;
    @FXML private Label profileStatusLabel;
    private int currentUserId;
    
    @FXML private TableView<TopRatedMovie> topRatedTable;
    @FXML private TableColumn<TopRatedMovie, String> topRatedTitleColumn;
    @FXML private TableColumn<TopRatedMovie, String> topRatedGenreColumn;
    @FXML private TableColumn<TopRatedMovie, Double> topRatedAvgRatingColumn;
    private final ObservableList<TopRatedMovie> topRatedMovies = FXCollections.observableArrayList();


    
    public void initialize(int userId, String username, String email) {
    	//System.out.println("💡 Label before update: " + welcomeLabel);

    	this.name = username;
    	//System.out.println("✅ CustomerDashboard initialized for " + username);

        welcomeLabel.setText("Welcome, " + username + "!");
        welcomeLabelAva.setText("Welcome, "+username + "!");
        this.currentUserId = userId;
        setupTable();
        loadAvailableMovies();
        availableMoviesTable.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        loadRentedMovies();
        rentedMoviesTable.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        loadUserDetails();
        loadDashboardMetrics();
        loadTopRatedMovies();

    }

    public void populateUserProfile(User user) {
        currentUserId = user.getUserId();
        firstNameField.setText(user.getFirstName());
        lastNameField.setText(user.getLastName());
        usernameField.setText(user.getUsername());
        emailField.setText(user.getEmail());
        phoneField.setText(user.getPhoneNumber());
        addressField.setText(user.getAddress());
    }

    public void debug() {
    	System.out.print("Test");
    }
    private void setupTable() {
        availableTitleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        availableGenreColumn.setCellValueFactory(new PropertyValueFactory<>("genre"));
        //availableStatusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
        availableReleaseDateColumn.setCellValueFactory(new PropertyValueFactory<>("releaseDate"));
        availableActorColumn.setCellValueFactory(new PropertyValueFactory<>("actor"));
        availableDirectorColumn.setCellValueFactory(new PropertyValueFactory<>("director"));
        
     // Enable multi-selection
        availableMoviesTable.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        availableMoviesTable.setItems(availableMovies);
        
     // rented table
        rentedTitleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        rentedGenreColumn.setCellValueFactory(new PropertyValueFactory<>("genre"));
        rentedDueDateColumn.setCellValueFactory(new PropertyValueFactory<>("dueDate"));
        
        
        rentedDueDateColumn.setCellFactory(column -> new TableCell<RentedMovie, LocalDate>() {
            @Override
               protected void updateItem(LocalDate dueDate, boolean empty) {
                   super.updateItem(dueDate, empty);
                   if (empty || dueDate == null) {
                       setText(null);
                       setStyle("");
                   } else {
                       setText(dueDate.toString());
                       if (dueDate.isBefore(LocalDate.now())) {
                           setStyle("-fx-text-fill: red; -fx-font-weight: bold;");
                       } else {
                           setStyle(""); // Reset to default
                       }
                   }
               }
           });
        
        //Rental History Table
        historyTitleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        historyRentalDateColumn.setCellValueFactory(new PropertyValueFactory<>("rentalDate"));
        historyDueDateColumn.setCellValueFactory(new PropertyValueFactory<>("dueDate"));
        historyReturnDateColumn.setCellValueFactory(new PropertyValueFactory<>("returnDate"));
        historyStatusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
        historyLateFeeColumn.setCellValueFactory(new PropertyValueFactory<>("lateFee"));
        historyRatingColumn.setCellValueFactory(new PropertyValueFactory<>("Rating"));

        historyLateFeeColumn.setCellFactory(column -> new TableCell<RentalHistoryRecord, Double>() {
            @Override
            protected void updateItem(Double fee, boolean empty) {
                super.updateItem(fee, empty);
                if (empty || fee == null) {
                    setText(null);
                } else {
                    setText(String.format("$%.2f", fee));
                    if (fee > 0.0) {
                        setStyle("-fx-text-fill: red; -fx-font-weight: bold;");
                    } else {
                        setStyle(""); // Reset to default
                    }                }
            }
            
        });
        
        historyRatingColumn.setCellFactory(column -> new TableCell<>() {
            private final HBox starsBox = new HBox(2); // spacing between stars

            @Override
            protected void updateItem(Integer rating, boolean empty) {
                super.updateItem(rating, empty);
                if (empty || rating == null) {
                    setGraphic(null);
                    return;
                }

                starsBox.getChildren().clear();
                for (int i = 1; i <= 5; i++) {
                    Label star = new Label(i <= rating ? "★" : "☆");
                    star.setStyle("-fx-font-size: 16; -fx-cursor: hand;");
                    int selectedRating = i;

                    star.setOnMouseClicked(event -> {
                        RentalHistoryRecord record = getTableView().getItems().get(getIndex());
                        record.setRating(selectedRating);
                        CustomerDashboardController.this.updateRatingInDatabase(record);
                        getTableView().refresh();
                    });

                    starsBox.getChildren().add(star);
                }
                setGraphic(starsBox);
            }
        });

        //top rate movie table
        topRatedTitleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        topRatedGenreColumn.setCellValueFactory(new PropertyValueFactory<>("genre"));
        topRatedAvgRatingColumn.setCellValueFactory(new PropertyValueFactory<>("averageRating"));
        topRatedAvgRatingColumn.setCellFactory(column -> new TableCell<TopRatedMovie, Double>() {
            @Override
            protected void updateItem(Double rating, boolean empty) {
                super.updateItem(rating, empty);
                if (empty || rating == null) {
                    setText(null);
                } else {
                    int fullStars = rating.intValue();
                    double decimal = rating - fullStars;
                    StringBuilder stars = new StringBuilder("★".repeat(fullStars));
                    if (decimal >= 0.5 && fullStars < 5) {
                        stars.append("☆");
                    }
                    while (stars.length() < 5) {
                        stars.append("☆");
                    }
                    setText(stars.toString());
                    setStyle("-fx-alignment: CENTER;");
                }
            }
        });

        rentalHistoryTable.setItems(rentalHistory);
        loadRentalHistory();
        
        
     }

    private void loadAvailableMovies() {
        //availableMovies.clear();
    	String query = """
    		    SELECT m.*
    		    FROM movies m
    		    LEFT JOIN (
    		        SELECT movie_id, MAX(rental_id) AS last_rental_id
    		        FROM rentals
    		        GROUP BY movie_id
    		    ) latest_rentals ON m.movie_id = latest_rentals.movie_id
    		    LEFT JOIN rentals r ON r.rental_id = latest_rentals.last_rental_id
    		    WHERE r.status = 'returned' OR r.rental_id IS NULL
    		""";

        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                availableMovies.add(new Movie(
                    rs.getInt("movie_id"),
                    rs.getString("title"),
                    rs.getString("genre"),
                    rs.getDate("release_date").toString(),
                    rs.getString("actor"),
                    rs.getString("director"),
                    rs.getString("description")
                ));
            }

            System.out.println("✅ Loaded movies from database: " + availableMovies.size());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
      @FXML  
       private void rentSelectedMovies() {
            ObservableList<Movie> selectedMovies = availableMoviesTable.getSelectionModel().getSelectedItems();
            if (selectedMovies == null || selectedMovies.isEmpty()) {
                System.out.println("⚠ No movies selected.");
                return;
            }

            String sql = "INSERT INTO rentals (user_id, movie_id, rental_date, due_date, status, late_fee) " +
                         "VALUES (?, ?, CURRENT_DATE, CURRENT_DATE + INTERVAL '7 days', 'rented', 0)";
            try (Connection conn = DatabaseConnector.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                
                for (Movie movie : selectedMovies) {
                    stmt.setInt(1, currentUserId);
                    stmt.setInt(2, movie.getMovieId());
                    stmt.addBatch();
                }

                stmt.executeBatch();
                System.out.println("✅ Rented " + selectedMovies.size() + " movie(s)");

                loadAvailableMovies();  // Refresh table
            } catch (SQLException e) {
                e.printStackTrace();
            }
            
       }
      public int getCurrentUserId() {
    	  return currentUserId;
      }
      
      @FXML
      private void handleRentButtonClick() {
          Movie selectedMovie = availableMoviesTable.getSelectionModel().getSelectedItem();
          if (selectedMovie == null) {
              showAlert("Please select a movie to rent.");
              return;
          }

          try {
              FXMLLoader loader = new FXMLLoader(getClass().getResource("/ui/RentMovieForm.fxml"));
              Parent root = loader.load();

              RentMovieFormController controller = loader.getController();
              controller.setData(selectedMovie, currentUserId);

              Stage stage = new Stage();
              stage.setTitle("Rent Movie");
              stage.setScene(new Scene(root));
              stage.show();
          } catch (IOException e) {
              e.printStackTrace();
          }
      }

      private void showAlert(String message) {
          Alert alert = new Alert(Alert.AlertType.INFORMATION);
          alert.setTitle("Notice");
          alert.setHeaderText(null);
          alert.setContentText(message);
          alert.showAndWait();
      }
      
      
      
      @FXML
      private void handleOpenRentForm() {
          Movie selectedMovie = availableMoviesTable.getSelectionModel().getSelectedItem();

          if (selectedMovie == null) {
              Alert alert = new Alert(Alert.AlertType.WARNING, "Please select a movie to rent.");
              alert.showAndWait();
              return;
          }

          try {
              FXMLLoader loader = new FXMLLoader(getClass().getResource("/ui/RentMovieForm.fxml"));
              Parent root = loader.load();

              RentMovieFormController controller = loader.getController();
              controller.setData(selectedMovie, currentUserId);

              Stage stage = new Stage();
              stage.setTitle("Rent Movie");
              stage.setScene(new Scene(root));
              stage.initModality(Modality.APPLICATION_MODAL);
              stage.showAndWait();

          } catch (IOException e) {
              e.printStackTrace();
          }
      }
      
      @FXML
      private void handleRentSelectedMovies() {
          ObservableList<Movie> selectedMovies = availableMoviesTable.getSelectionModel().getSelectedItems();

          if (selectedMovies.isEmpty()) {
              Alert alert = new Alert(Alert.AlertType.WARNING, "Please select at least one movie to rent.");
              alert.showAndWait();
              return;
          }
          
          RentSummaryDialogController.openDialog(selectedMovies, currentUserId);

          try (Connection conn = DatabaseConnector.getConnection()) {
              conn.setAutoCommit(false);
              String sql = "INSERT INTO rentals (user_id, movie_id, rental_date, due_date, status, late_fee) " +
                           "VALUES (?, ?, CURRENT_DATE, CURRENT_DATE + INTERVAL '7 days', 'rented', 0)";
              try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                  for (Movie movie : selectedMovies) {
                      stmt.setInt(1, currentUserId);
                      stmt.setInt(2, movie.getMovieId());
                      stmt.addBatch();
                  }
                  stmt.executeBatch();
                  conn.commit();
              } catch (SQLException e) {
                  conn.rollback();
                  e.printStackTrace();
              }
          } catch (SQLException e) {
              e.printStackTrace();
          }

          loadAvailableMovies(); // Refresh the table
      }

      public void setUsername(String username) {
    	  welcomeLabel.setText("Welcome, "+username+ "1");
      }
      
      private void loadRentedMovies() {
    	    rentedMovies.clear();
    	    String sql = "SELECT m.title, m.genre, r.due_date " +
    	                 "FROM rentals r " +
    	                 "JOIN movies m ON r.movie_id = m.movie_id " +
    	                 "WHERE r.user_id = ? AND r.status = 'rented'";

    	    try (Connection conn = DatabaseConnector.getConnection();
    	         PreparedStatement stmt = conn.prepareStatement(sql)) {

    	        stmt.setInt(1, currentUserId);
    	        ResultSet rs = stmt.executeQuery();

    	        while (rs.next()) {
    	            String title = rs.getString("title");
    	            String genre = rs.getString("genre");
    	            LocalDate dueDate = rs.getDate("due_date").toLocalDate();

    	            rentedMovies.add(new RentedMovie(title, genre, dueDate));
    	        }

    	    } catch (SQLException e) {
    	        e.printStackTrace();
    	    }

    	    rentedMoviesTable.setItems(rentedMovies);
    	}
      
      @FXML
      private void handleReturnSelectedMovies() {
          ObservableList<RentedMovie> selectedMovies = rentedMoviesTable.getSelectionModel().getSelectedItems();

          if (selectedMovies.isEmpty()) {
        	  Alert alert = new Alert(Alert.AlertType.WARNING, "Please select at least one movie to return.");
              alert.showAndWait();
              return;
          }

          String sql = "UPDATE rentals SET status = 'returned', return_date = CURRENT_DATE " +
                  "WHERE user_id = ? " +
                  "AND movie_id = (SELECT movie_id FROM movies WHERE title = ? AND genre = ?) " +
                  "AND due_date = ? AND status = 'rented'";

          try (Connection conn = DatabaseConnector.getConnection();
               PreparedStatement stmt = conn.prepareStatement(sql)) {

              for (RentedMovie movie : selectedMovies) {
            	  stmt.setInt(1, currentUserId);
            	  stmt.setString(2, movie.getTitle());
            	  stmt.setString(3, movie.getGenre());
            	  stmt.setDate(4, java.sql.Date.valueOf(movie.getDueDate()));
                  stmt.executeUpdate();
              }

              Alert showAlert = new Alert(Alert.AlertType.INFORMATION, "Success, Selected movie(s) returned successfully.");
              showAlert.showAndWait();
              loadRentedMovies();  // Refresh the table

          } catch (SQLException e) {
              e.printStackTrace();
              Alert errorAlert = new Alert(Alert.AlertType.INFORMATION, "An error occured while returning the movie");
          }
      }
      
      private void loadRentalHistory() {
    	  
    	    rentalHistory.clear();
    	    String sql = "SELECT " +
    	            "r.movie_id, m.title, r.rental_date, r.due_date, r.return_date, r.status, r.late_fee, " +
    	            "COALESCE(rt.rating, 0) AS rating " +
    	            "FROM rentals r " +
    	            "JOIN movies m ON r.movie_id = m.movie_id " +
    	            "LEFT JOIN ratings rt ON rt.user_id = r.user_id AND rt.movie_id = r.movie_id " +
    	            "WHERE r.user_id = ?";

    	    try (Connection conn = DatabaseConnector.getConnection();
    	         PreparedStatement stmt = conn.prepareStatement(sql)) {

    	        stmt.setInt(1, currentUserId);
    	        ResultSet rs = stmt.executeQuery();
      	        while (rs.next()) {
    	            String title = rs.getString("title");
    	            LocalDate rentalDate = rs.getDate("rental_date").toLocalDate();
    	            LocalDate dueDate = rs.getDate("due_date") != null ? rs.getDate("due_date").toLocalDate() : null;
    	            LocalDate returnDate = null;
    	            if (rs.getDate("return_date") != null) {
    	                returnDate = rs.getDate("return_date").toLocalDate();
    	            }
    	            String status = rs.getString("status");
    	            double lateFee = 0.0;
    	            if ("returned".equalsIgnoreCase(status) && returnDate != null && returnDate.isAfter(dueDate)) {
    	                long daysLate = java.time.temporal.ChronoUnit.DAYS.between(dueDate, returnDate);
    	                lateFee = daysLate * 3.0;
    	            }
    	            int rating = rs.getInt("rating"); // Will be 0 if NULL
    	            int movieId = rs.getInt("movie_id");
    	            int userId = currentUserId; // if not already defined, use the logged-in user's ID
    	            rentalHistory.add(new RentalHistoryRecord(title, rentalDate, dueDate, returnDate, status, lateFee, rating, movieId, userId));
    	        }
      	        rentalHistoryTable.setItems(rentalHistory);
    	    } catch (SQLException e) {
    	        e.printStackTrace();
    	    }
    	}

      private void updateRatingInDatabase(RentalHistoryRecord record) {
    	    String sql = """
    	        INSERT INTO ratings (user_id, movie_id, rating)
    	        VALUES (?, ?, ?)
    	        ON CONFLICT (user_id, movie_id) DO UPDATE SET rating = EXCLUDED.rating
    	        """;

    	    try (Connection conn = DatabaseConnector.getConnection();
    	         PreparedStatement stmt = conn.prepareStatement(sql)) {

    	        stmt.setInt(1, record.getUserId());
    	        stmt.setInt(2, record.getMovieId());
    	        stmt.setInt(3, record.getRating());

    	        int rows = stmt.executeUpdate();
    	        System.out.println("✅ Rating saved to database."+rows+ "rows");
    	    } catch (SQLException e) {
    	        e.printStackTrace();
    	    }
    	}

      @FXML
      private void handleUpdateProfile() {
          try (Connection conn = DatabaseConnector.getConnection()) {
              String sql = "UPDATE users SET first_name=?, last_name=?, email=?, password =?, phone_number=?, address=? WHERE user_id=?";
              PreparedStatement stmt = conn.prepareStatement(sql);
              stmt.setString(1, firstNameField.getText());
              stmt.setString(2, lastNameField.getText());
              stmt.setString(3, emailField.getText());
              stmt.setString(4, passwordField.getText());
              stmt.setString(5, phoneField.getText());
              stmt.setString(6, addressField.getText());
              stmt.setInt(7, currentUserId); // ✅ Use the int directly

              int rowsUpdated = stmt.executeUpdate();
              if (rowsUpdated > 0) {
                  Alert alert = new Alert(Alert.AlertType.INFORMATION, "Profile updated successfully!");
                  alert.show();
              }
          } catch (SQLException e) {
              e.printStackTrace();
              Alert alert = new Alert(Alert.AlertType.ERROR, "Update failed.");
              alert.show();
          }
      }
      
      private void loadUserDetails() {
    	    String sql = "SELECT first_name, last_name, username, email, password, phone_number, address FROM users WHERE user_id = ?";
    	    try (Connection conn = DatabaseConnector.getConnection();
    	         PreparedStatement stmt = conn.prepareStatement(sql)) {

    	        stmt.setInt(1, currentUserId);
    	        ResultSet rs = stmt.executeQuery();

    	        if (rs.next()) {
    	            firstNameField.setText(rs.getString("first_name"));
    	            lastNameField.setText(rs.getString("last_name"));
    	            usernameField.setText(rs.getString("username"));
    	            passwordField.setText(rs.getString("password"));
    	            emailField.setText(rs.getString("email"));
    	            phoneField.setText(rs.getString("phone_number"));
    	            addressField.setText(rs.getString("address"));
    	        }

    	    } catch (SQLException e) {
    	        e.printStackTrace();
    	    }
      }      
      
      private void loadDashboardMetrics() {
    	    String sql = """
    	    			SELECT
    	    			COUNT(*) FILTER (WHERE status IN ('rented', 'returned')) AS total,
    	    			COUNT(*) FILTER (WHERE status = 'rented') AS current,
    	    			COUNT(*) FILTER (WHERE status = 'rented' AND due_date < CURRENT_DATE) AS overdue,
    	    			COALESCE(SUM(late_fee), MONEY '0.00') AS late_fees
    	    			FROM rentals
    	    			WHERE user_id = ?
    	    			""";

    	    try (Connection conn = DatabaseConnector.getConnection();
    	         PreparedStatement stmt = conn.prepareStatement(sql)) {
    	        stmt.setInt(1, currentUserId);
    	        ResultSet rs = stmt.executeQuery();

    	        if (rs.next()) {
    	            totalRentedLabel.setText(String.valueOf(rs.getInt("total")));
    	            currentlyRentedLabel.setText(String.valueOf(rs.getInt("current")));
    	            overdueMoviesLabel.setText(String.valueOf(rs.getInt("overdue")));
    	            lateFeesLabel.setText("$" + String.format("%.2f", rs.getDouble("late_fees")));
    	        }
    	    } catch (SQLException e) {
    	        e.printStackTrace();
    	    }
    	}

      private void loadTopRatedMovies() {
    	    String sql = """
    	        SELECT m.title, m.genre, ROUND(AVG(r.rating), 2) AS avg_rating
				FROM movies m
				JOIN ratings r ON m.movie_id = r.movie_id
				GROUP BY m.title, m.genre
				ORDER BY avg_rating DESC
				LIMIT 10;
    	    """;

    	    try (Connection conn = DatabaseConnector.getConnection();
    	         PreparedStatement stmt = conn.prepareStatement(sql);
    	         ResultSet rs = stmt.executeQuery()) {

    	        topRatedMovies.clear();
    	        while (rs.next()) {
    	            TopRatedMovie topMovie = new TopRatedMovie(
    	                rs.getString("title"),
    	                rs.getString("genre"),
    	                rs.getDouble("avg_rating")
    	            );
    	            topRatedMovies.add(topMovie);
    	        }

    	        topRatedTable.setItems(topRatedMovies);

    	    } catch (SQLException e) {
    	        e.printStackTrace();
    	    }
    	}
      
      @FXML
      private void handleLogout() {
          try {
              FXMLLoader loader = new FXMLLoader(getClass().getResource("/ui/LoginView.fxml"));
              Parent root = loader.load();
              Stage stage = (Stage) welcomeLabel.getScene().getWindow();
              stage.setScene(new Scene(root));
              stage.setTitle("Login");
              stage.show();
          } catch (IOException e) {
              e.printStackTrace();
          }
      }

      
} 
