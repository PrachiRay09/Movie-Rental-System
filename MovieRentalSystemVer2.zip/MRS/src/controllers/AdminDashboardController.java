package controllers;

import javafx.fxml.FXML;

public class AdminDashboardController {

    @FXML
    public void initialize() {
        // Dashboard charts are now handled by AdminChartsController.
    }
}
