package controllers;

public class SessionManager {
    private static String currentUserRole;
    private static String currentUsername;
    private static int currentUserId;
    private static String currentUserEmail;


    public static void setCurrentUserRole(String role) {
        currentUserRole = role;
    }

    public static String getCurrentUserRole() {
        return currentUserRole;
    }

    public static void setCurrentUsername(String username) {
        currentUsername = username;
    }

    public static String getCurrentUsername() {
        return currentUsername;
    }
 
    public static void setCurrentUserId(int id) {
        currentUserId = id;
    }
    public static int getCurrentUserId() {
        return currentUserId;
    }

    public static void setCurrentUserEmail(String email) {
        currentUserEmail = email;
    }
    public static String getCurrentUserEmail() {
        return currentUserEmail;
    }

}
