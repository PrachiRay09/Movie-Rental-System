package controllers;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import models.Rental;

public class RentalManagementController {

    @FXML
    private TableView<Rental> rentalTable;
    @FXML
    private TableColumn<Rental, String> userColumn, movieColumn, rentalDateColumn, dueDateColumn, statusColumn;

    @FXML
    private TextField userField, movieField;
    @FXML
    private DatePicker dueDatePicker;
    @FXML
    private Button rentButton, returnButton, clearButton;

    private final ObservableList<Rental> rentalList = FXCollections.observableArrayList();

    public void initialize() {
        userColumn.setCellValueFactory(cellData -> cellData.getValue().userProperty());
        movieColumn.setCellValueFactory(cellData -> cellData.getValue().movieProperty());
        rentalDateColumn.setCellValueFactory(cellData -> cellData.getValue().rentalDateProperty());
        dueDateColumn.setCellValueFactory(cellData -> cellData.getValue().dueDateProperty());
        statusColumn.setCellValueFactory(cellData -> cellData.getValue().statusProperty());

        rentalTable.setItems(rentalList);

        rentButton.setOnAction(e -> rentMovie());
        returnButton.setOnAction(e -> returnMovie());
        clearButton.setOnAction(e -> clearFields());
    }

    private void rentMovie() {
        Rental rental = new Rental(
            userField.getText(),
            movieField.getText(),
            java.time.LocalDate.now().toString(),
            dueDatePicker.getValue().toString(),
            "rented"
        );
        rentalList.add(rental);
        clearFields();
    }

    private void returnMovie() {
        Rental selected = rentalTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            selected.setStatus("returned");
            rentalTable.refresh();
        }
    }

    private void clearFields() {
        userField.clear();
        movieField.clear();
        dueDatePicker.setValue(null);
    }
}