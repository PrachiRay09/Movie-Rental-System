package controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.collections.*;
import javafx.event.ActionEvent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import models.Movie;
import models.OverdueRental;
import utils.DatabaseConnector;

import java.io.IOException;
import java.sql.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.stream.Collectors;

public class StaffDashboardController {

    @FXML private PieChart movieAvailabilityChart;
    //@FXML private BarChart<String, Number> rentalStatusChart;
    @FXML private BarChart<String, Number> rentalStatusChart;


    @FXML private TextField searchField;
    @FXML private ComboBox<String> genreFilterComboBox;
    @FXML private ComboBox<String> newGenreComboBox;
    @FXML private TextField customerUsernameField;
    @FXML private TableView<Movie> movieTable;
    @FXML private TableColumn<Movie, String> titleColumn;
    @FXML private TableColumn<Movie, String> genreColumn;
    @FXML private TableColumn<Movie, String> statusColumn;
    @FXML private Button rentButton;
    @FXML private Button returnButton;
    @FXML private Button notifyButton;

    @FXML private TableView<OverdueRental> overdueTable;
    @FXML private TableColumn<OverdueRental, String> overdueMovieColumn;
    @FXML private TableColumn<OverdueRental, String> overdueCustomerColumn;
    @FXML private TableColumn<OverdueRental, String> overdueDueDateColumn;
    @FXML private TableColumn<OverdueRental, Integer> overdueDaysColumn;

    @FXML private TextField newTitleField, newActorField, newDirectorField;
    @FXML private DatePicker newReleaseDatePicker;
    @FXML private TextArea newDescriptionArea;
    @FXML private Button saveMovieButton, updateMovieButton, deleteMovieButton;
    @FXML private Label movieActionStatusLabel;
    @FXML private TableView<Movie> movieListTable;
    @FXML private TableColumn<Movie, String> listTitleColumn, listGenreColumn, listReleaseDateColumn, listActorColumn, listDirectorColumn;

    private final ObservableList<Movie> masterMovieList = FXCollections.observableArrayList();
    private final ObservableList<Movie> filteredMovieList = FXCollections.observableArrayList();
    private final ObservableList<Movie> movieList = FXCollections.observableArrayList();
    
    @FXML  private Hyperlink logoutLink;
    public void initialize() {
        updateCharts();
        setupRentalTable();
        setupOverdueTable();
        setupAddMovieTab();
        genreFilterComboBox.setItems(FXCollections.observableArrayList("All", "Action", "Drama", "Comedy", "Horror", "Thriller", "Sci-Fi"));
        genreFilterComboBox.setValue("All");
        newGenreComboBox.setItems(genres);
        loadMovies();
        loadOverdueRentals();
        loadMovieList();
        loadRentalStatusChart();

    }

    private void updateCharts() {
        try (Connection conn = DatabaseConnector.getConnection()) {
            // PieChart - Movie Availability
            int available = 0;
            int rented = 0;
            String query = "SELECT status, COUNT(*) as count FROM (" +
                           "SELECT m.movie_id, CASE WHEN r.status = 'rented' THEN 'Rented' ELSE 'Available' END AS status " +
                           "FROM movies m LEFT JOIN rentals r ON m.movie_id = r.movie_id AND r.return_date IS NULL) AS movie_status " +
                           "GROUP BY status";
            try (PreparedStatement stmt = conn.prepareStatement(query);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    String status = rs.getString("status");
                    int count = rs.getInt("count");
                    if ("Available".equals(status)) available = count;
                    else if ("Rented".equals(status)) rented = count;
                }
            }
            ObservableList<PieChart.Data> pieData = FXCollections.observableArrayList(
                new PieChart.Data("Available", available),
                new PieChart.Data("Rented", rented)
            );
            movieAvailabilityChart.setData(pieData);

            // Display values in labels
            for (PieChart.Data data : pieData) {
                data.nameProperty().set(data.getName() + " (" + (int)data.getPieValue() + ")");
            }

            // BarChart - Rental Status
            int returned = 0;
            int overdue = 0;
            String barQuery = "SELECT status, COUNT(*) as count FROM rentals WHERE return_date IS NULL GROUP BY status";
            try (PreparedStatement stmt = conn.prepareStatement(barQuery);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    String status = rs.getString("status");
                    int count = rs.getInt("count");
                    if ("returned".equalsIgnoreCase(status)) returned = count;
                    else if ("overdue".equalsIgnoreCase(status)) overdue = count;
                }
            }
            XYChart.Series<String, Number> barSeries = new XYChart.Series<>();
            barSeries.setName("Status");
            barSeries.getData().add(new XYChart.Data<>("Returned", returned));
            barSeries.getData().add(new XYChart.Data<>("Overdue", overdue));
            rentalStatusChart.getData().clear();
            rentalStatusChart.getData().add(barSeries);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    private void setupRentalTable() {
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        genreColumn.setCellValueFactory(new PropertyValueFactory<>("genre"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));

        movieTable.setItems(filteredMovieList);
        searchField.textProperty().addListener((obs, oldVal, newVal) -> filterMovies());
        genreFilterComboBox.setOnAction(e -> filterMovies());

        rentButton.setOnAction(e -> rentMovie());
        returnButton.setOnAction(e -> returnMovie());
        notifyButton.setOnAction(e -> notifyCustomer());
    }

    private void setupOverdueTable() {
        overdueMovieColumn.setCellValueFactory(new PropertyValueFactory<>("movieTitle"));
        overdueCustomerColumn.setCellValueFactory(new PropertyValueFactory<>("customerUsername"));
        overdueDueDateColumn.setCellValueFactory(new PropertyValueFactory<>("dueDate"));
        overdueDaysColumn.setCellValueFactory(new PropertyValueFactory<>("daysOverdue"));
    }

    private void setupAddMovieTab() {
        listTitleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        listGenreColumn.setCellValueFactory(new PropertyValueFactory<>("genre"));
        listReleaseDateColumn.setCellValueFactory(new PropertyValueFactory<>("releaseDate"));
        listActorColumn.setCellValueFactory(new PropertyValueFactory<>("actor"));
        listDirectorColumn.setCellValueFactory(new PropertyValueFactory<>("director"));
        movieListTable.setItems(movieList);

        saveMovieButton.setOnAction(e -> saveNewMovie());
        updateMovieButton.setOnAction(e -> updateSelectedMovie());
        deleteMovieButton.setOnAction(e -> deleteSelectedMovie());
        movieListTable.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> populateForm(newVal));
    }

    private void saveNewMovie() {
        String query = "INSERT INTO movies (title, genre, release_date, actor, director, description) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, newTitleField.getText());
            stmt.setString(2, newGenreComboBox.getValue());
            stmt.setDate(3, Date.valueOf(newReleaseDatePicker.getValue()));
            stmt.setString(4, newActorField.getText());
            stmt.setString(5, newDirectorField.getText());
            stmt.setString(6, newDescriptionArea.getText());
            stmt.executeUpdate();
            loadMovieList();
            movieActionStatusLabel.setText("Movie added successfully.");
            clearMovieForm();
        } catch (SQLException e) {
            e.printStackTrace();
            movieActionStatusLabel.setText("Failed to add movie.");
        }
    }

    private void populateForm(Movie movie) {
        if (movie == null) return;
        newTitleField.setText(movie.getTitle());
        newGenreComboBox.setValue(movie.getGenre());
        newReleaseDatePicker.setValue(LocalDate.parse(movie.getReleaseDate()));
        newActorField.setText(movie.getActor());
        newDirectorField.setText(movie.getDirector());
        newDescriptionArea.setText(movie.getDescription());
    }

    private void updateSelectedMovie() {
        Movie selected = movieListTable.getSelectionModel().getSelectedItem();
        if (selected == null) return;

        String query = "UPDATE movies SET title=?, genre=?, release_date=?, actor=?, director=?, description=? WHERE movie_id=?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, newTitleField.getText());
            stmt.setString(2, newGenreComboBox.getValue());
            stmt.setDate(3, Date.valueOf(newReleaseDatePicker.getValue()));
            stmt.setString(4, newActorField.getText());
            stmt.setString(5, newDirectorField.getText());
            stmt.setString(6, newDescriptionArea.getText());
            stmt.setInt(7, selected.getMovieId());
            stmt.executeUpdate();
            loadMovieList();
            movieActionStatusLabel.setText("Movie updated successfully.");
            clearMovieForm();
        } catch (SQLException e) {
            e.printStackTrace();
            movieActionStatusLabel.setText("Failed to update movie.");
        }
    }

    private void deleteSelectedMovie() {
        Movie selected = movieListTable.getSelectionModel().getSelectedItem();
        if (selected == null) return;

        String query = "DELETE FROM movies WHERE movie_id = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, selected.getMovieId());
            stmt.executeUpdate();
            loadMovieList();
            movieActionStatusLabel.setText("Movie deleted successfully.");
            clearMovieForm();
        } catch (SQLException e) {
            e.printStackTrace();
            movieActionStatusLabel.setText("Failed to delete movie.");
        }
    }

    private void loadMovies() {
        masterMovieList.clear();
        String query = "SELECT m.movie_id, m.title, m.genre, r.status FROM movies m " +
                "LEFT JOIN rentals r ON m.movie_id = r.movie_id AND r.return_date IS NULL";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                String status = rs.getString("status");
                if (status == null) status = "Available";
                masterMovieList.add(new Movie(
                        rs.getInt("movie_id"),
                        rs.getString("title"),
                        rs.getString("genre"),
                        status
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        filterMovies();
    }

    private void filterMovies() {
        String search = searchField.getText().toLowerCase();
        String genreFilter = genreFilterComboBox.getValue();

        filteredMovieList.setAll(masterMovieList.stream().filter(movie -> {
            boolean matchesSearch = search.isEmpty() || movie.getTitle().toLowerCase().contains(search);
            boolean matchesGenre = genreFilter == null || genreFilter.equals("All") || movie.getGenre().equalsIgnoreCase(genreFilter);
            return matchesSearch && matchesGenre;
        }).collect(Collectors.toList()));
    }

    private void rentMovie() {
        Movie selected = movieTable.getSelectionModel().getSelectedItem();
        String username = customerUsernameField.getText().trim();
        if (selected == null || username.isEmpty()) return;

        try (Connection conn = DatabaseConnector.getConnection()) {
            PreparedStatement userStmt = conn.prepareStatement("SELECT user_id FROM users WHERE username = ?");
            userStmt.setString(1, username);
            ResultSet userRs = userStmt.executeQuery();
            if (!userRs.next()) return;
            int userId = userRs.getInt("user_id");

            PreparedStatement rentStmt = conn.prepareStatement(
                    "INSERT INTO rentals (user_id, movie_id, rental_date, due_date, status, late_fee) " +
                            "VALUES (?, ?, CURRENT_DATE, CURRENT_DATE + INTERVAL '7 day', 'rented', 0)");
            rentStmt.setInt(1, userId);
            rentStmt.setInt(2, selected.getMovieId());
            rentStmt.executeUpdate();

            loadMovies();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void returnMovie() {
        Movie selected = movieTable.getSelectionModel().getSelectedItem();
        if (selected == null) return;

        try (Connection conn = DatabaseConnector.getConnection()) {
            PreparedStatement stmt = conn.prepareStatement(
                    "UPDATE rentals SET return_date = CURRENT_DATE, status = 'returned' WHERE movie_id = ? AND return_date IS NULL");
            stmt.setInt(1, selected.getMovieId());
            stmt.executeUpdate();
            loadMovies();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void notifyCustomer() {
        System.out.println("Overdue notifications feature pending implementation.");
    }

    private void loadOverdueRentals() {
        ObservableList<OverdueRental> overdueList = FXCollections.observableArrayList();
        String query = "SELECT m.title, u.username, r.due_date FROM rentals r " +
                "JOIN users u ON r.user_id = u.user_id " +
                "JOIN movies m ON r.movie_id = m.movie_id " +
                "WHERE r.status = 'rented' AND r.due_date < CURRENT_DATE";

        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                LocalDate dueDate = rs.getDate("due_date").toLocalDate();
                int daysOverdue = (int) ChronoUnit.DAYS.between(dueDate, LocalDate.now());
                overdueList.add(new OverdueRental(
                        rs.getString("title"),
                        rs.getString("username"),
                        dueDate.toString(),
                        daysOverdue
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        overdueTable.setItems(overdueList);
    }
    
    private void loadMovieList() {
        movieList.clear();
        String query = "SELECT * FROM movies";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                movieList.add(new Movie(
                        rs.getInt("movie_id"),
                        rs.getString("title"),
                        rs.getString("genre"),
                        rs.getDate("release_date").toString(),
                        rs.getString("actor"),
                        rs.getString("director"),
                        rs.getString("description")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private void clearMovieForm() {
        newTitleField.clear();
        newGenreComboBox.setValue(null);
        newReleaseDatePicker.setValue(null);
        newActorField.clear();
        newDirectorField.clear();
        newDescriptionArea.clear();
        movieListTable.getSelectionModel().clearSelection();
        movieActionStatusLabel.setText("");
    }

    private final ObservableList<String> genres = FXCollections.observableArrayList(
            "Action", "Adventure", "Animation", "Biography", "Comedy", "Crime", "Documentary", "Drama", "Family",
            "Fantasy", "History", "Horror", "Music", "Musical", "Mystery", "Romance", "Sci-Fi", "Sport", "Thriller",
            "War", "Western"
    );
    
    private void loadRentalStatusChart() {
        String sql = """
            SELECT status, COUNT(*) as count
            FROM rentals
            WHERE status IN ('rented', 'returned', 'overdue')
            GROUP BY status;
        """;

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Status");

        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                String status = rs.getString("status");
                int count = rs.getInt("count");
                String formattedStatus = status.substring(0, 1).toUpperCase() + status.substring(1);

                XYChart.Data<String, Number> data = new XYChart.Data<>(formattedStatus, count);

                // Add listener to apply color after node is created
                data.nodeProperty().addListener((obs, oldNode, newNode) -> {
                    if (newNode != null) {
                        switch (status.toLowerCase()) {
                            case "rented" -> newNode.setStyle("-fx-bar-fill: #f39c12;");   // Orange
                            case "returned" -> newNode.setStyle("-fx-bar-fill: #27ae60;"); // Green
                            case "overdue" -> newNode.setStyle("-fx-bar-fill: #e74c3c;");  // Red
                        }
                    }
                });

                series.getData().add(data);
            }

            rentalStatusChart.getData().clear();
            rentalStatusChart.getData().add(series);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    @FXML
    private void handleLogout(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/ui/LoginView.fxml")); // Make sure this path is correct!
            Parent root = loader.load();

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }



}
