package controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import models.Movie;
import utils.DatabaseConnector;

import java.io.IOException;
import java.sql.*;
import java.util.stream.Collectors;

public class MovieManagementController {

    @FXML private TableView<Movie> movieTable;
    @FXML private TableColumn<Movie, String> titleColumn;
    @FXML private TableColumn<Movie, String> genreColumn;
    @FXML private TableColumn<Movie, String> releaseDateColumn;
    @FXML private TableColumn<Movie, String> actorColumn;
    @FXML private TableColumn<Movie, String> directorColumn;

    @FXML private TextField titleField, genreField, actorField, directorField;
    @FXML private DatePicker releaseDatePicker;
    @FXML private TextArea descriptionArea;
    @FXML private Button addButton, updateButton, deleteButton, clearButton;
    @FXML private TextField searchField;
    @FXML private ComboBox<String> genreFilterComboBox;

    private final ObservableList<Movie> masterMovieList = FXCollections.observableArrayList();
    private final ObservableList<Movie> filteredMovieList = FXCollections.observableArrayList();

    public void initialize() {
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        genreColumn.setCellValueFactory(new PropertyValueFactory<>("genre"));
        releaseDateColumn.setCellValueFactory(new PropertyValueFactory<>("releaseDate"));
        actorColumn.setCellValueFactory(new PropertyValueFactory<>("actor"));
        directorColumn.setCellValueFactory(new PropertyValueFactory<>("director"));

        movieTable.setItems(filteredMovieList);

        genreFilterComboBox.setItems(FXCollections.observableArrayList("All", "Action", "Drama", "Comedy", "Horror", "Thriller", "Sci-Fi"));
        genreFilterComboBox.setValue("All");

        searchField.textProperty().addListener((obs, oldVal, newVal) -> filterMovies());
        genreFilterComboBox.setOnAction(e -> filterMovies());

        addButton.setOnAction(e -> addMovie());
        updateButton.setOnAction(e -> updateMovie());
        deleteButton.setOnAction(e -> deleteMovie());
        clearButton.setOnAction(e -> clearFields());

        movieTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> populateForm(newSel));

        loadMovies();
    }

    public void loadMovies() {
        masterMovieList.clear();
        String query = "SELECT * FROM movies";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                masterMovieList.add(new Movie(
                    rs.getInt("movie_id"),
                    rs.getString("title"),
                    rs.getString("genre"),
                    rs.getDate("release_date").toString(),
                    rs.getString("actor"),
                    rs.getString("director"),
                    rs.getString("description")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        filterMovies();
    }

    private void addMovie() {
        String query = "INSERT INTO movies (title, genre, release_date, actor, director, description) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, titleField.getText());
            stmt.setString(2, genreField.getText());
            stmt.setDate(3, Date.valueOf(releaseDatePicker.getValue()));
            stmt.setString(4, actorField.getText());
            stmt.setString(5, directorField.getText());
            stmt.setString(6, descriptionArea.getText());
            stmt.executeUpdate();
            loadMovies();
            clearFields();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void updateMovie() {
        Movie selected = movieTable.getSelectionModel().getSelectedItem();
        if (selected == null) return;

        String query = "UPDATE movies SET title=?, genre=?, release_date=?, actor=?, director=?, description=? WHERE movie_id=?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, titleField.getText());
            stmt.setString(2, genreField.getText());
            stmt.setDate(3, Date.valueOf(releaseDatePicker.getValue()));
            stmt.setString(4, actorField.getText());
            stmt.setString(5, directorField.getText());
            stmt.setString(6, descriptionArea.getText());
            stmt.setInt(7, selected.getMovieId());
            stmt.executeUpdate();
            loadMovies();
            clearFields();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void deleteMovie() {
        Movie selected = movieTable.getSelectionModel().getSelectedItem();
        if (selected == null) return;

        String query = "DELETE FROM movies WHERE movie_id = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, selected.getMovieId());
            stmt.executeUpdate();
            loadMovies();
            clearFields();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void clearFields() {
        titleField.clear();
        genreField.clear();
        releaseDatePicker.setValue(null);
        actorField.clear();
        directorField.clear();
        descriptionArea.clear();
        movieTable.getSelectionModel().clearSelection();
    }

    private void populateForm(Movie movie) {
        if (movie == null) return;
        titleField.setText(movie.getTitle());
        genreField.setText(movie.getGenre());
        releaseDatePicker.setValue(java.time.LocalDate.parse(movie.getReleaseDate()));
        actorField.setText(movie.getActor());
        directorField.setText(movie.getDirector());
        descriptionArea.setText(movie.getDescription());
    }

    private void filterMovies() {
        String search = searchField.getText().toLowerCase();
        String genreFilter = genreFilterComboBox.getValue();

        filteredMovieList.setAll(masterMovieList.stream().filter(movie -> {
            boolean matchesSearch = search.isEmpty()
                || movie.getTitle().toLowerCase().contains(search)
                || movie.getActor().toLowerCase().contains(search)
                || movie.getDirector().toLowerCase().contains(search);
            boolean matchesGenre = genreFilter.equals("All") || movie.getGenre().equalsIgnoreCase(genreFilter);
            return matchesSearch && matchesGenre;
        }).collect(Collectors.toList()));
    }
    
    @FXML
    private void handleLogout(ActionEvent event) {
        try {
            // Load the login view FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/ui/LoginView.fxml"));
            Parent loginRoot = loader.load();

            // Get the current stage and set the login scene
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loginRoot);
            stage.setScene(scene);
            stage.setTitle("Login");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

} 
