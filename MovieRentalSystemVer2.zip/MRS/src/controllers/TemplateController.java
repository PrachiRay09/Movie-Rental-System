package controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.StackPane;
import javafx.scene.Node;
import javafx.fxml.FXMLLoader;
import java.io.IOException;

public class TemplateController {

    @FXML
    private TabPane tabPane;
    @FXML
    private StackPane contentArea;
    @FXML
    private Tab tabUsers;

    public void initialize() {
        loadContent("AdminDashboard.fxml", contentArea);
        
        tabPane.getSelectionModel().selectedItemProperty().addListener((observable, oldTab, newTab) -> {
            switch (newTab.getText()) {
                case "Dashboard":
                    loadContent("AdminDashboard.fxml", contentArea);
                    break;
                case "Movies":
                    loadContent("MovieManagement.fxml", contentArea);
                    break;
                case "Rentals":
                    loadContent("RentalManagement.fxml", contentArea);
                    break;
                case "Users":
                    loadContent("UserManagement.fxml", contentArea);
                    break;
            }
        });
    }

    private void loadContent(String fxml, StackPane container) {
        try {
            Node content = FXMLLoader.load(getClass().getResource("/views/" + fxml));
            container.getChildren().setAll(content);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
