package controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import application.MainApp;
import utils.DatabaseConnector;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginController {

    @FXML    private TextField usernameField;
    @FXML    private PasswordField passwordField;
    @FXML    private Button loginButton;
    @FXML    private Label errorLabel;
    @FXML    private Button registerButton;
    @FXML
    public void initialize() {
        loginButton.setOnAction(e -> handleLogin());
        registerButton.setOnAction(e -> MainApp.showRegisterScreen());
    }

	
	  private void handleLogin() { String username = usernameField.getText();
	  String password = passwordField.getText();
	  
	  	if (authenticateUser(username, password)) { 
	  		MainApp.showDashboard(); 
	  		} 
	  	else {
	  		errorLabel.setText("Invalid username or password.");
	  		errorLabel.setVisible(true); 
	  		} 
	  }
	 
	  

	  private boolean authenticateUser(String username, String password) {
		    String query = "SELECT user_id, username, role, first_name, last_name, email FROM users WHERE username = ? AND password = ?";
		    try (Connection conn = DatabaseConnector.getConnection();
		         PreparedStatement stmt = conn.prepareStatement(query)) {

		        stmt.setString(1, username);
		        stmt.setString(2, password);
		        ResultSet rs = stmt.executeQuery();
		        if (rs.next()) {
		            int userId = rs.getInt("user_id");
		            String role = rs.getString("role");
		            String fullName = rs.getString("first_name") + " " + rs.getString("last_name");
		            String email = rs.getString("email");
		            String userName = rs.getString("username");

		            SessionManager.setCurrentUserId(userId);
		            SessionManager.setCurrentUserRole(role);
		            SessionManager.setCurrentUsername(fullName);
		            SessionManager.setCurrentUserEmail(email);
		            SessionManager.setCurrentUsername(userName);
		            return true;
		        }
		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		    return false;
		}

}