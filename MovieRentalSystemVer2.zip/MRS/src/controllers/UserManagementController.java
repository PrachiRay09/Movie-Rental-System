package controllers;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import models.User;
import utils.DatabaseConnector;

import java.io.IOException;
import java.sql.*;

public class UserManagementController {

    @FXML private TextField searchField;
    @FXML private ComboBox<String> roleFilterComboBox;
    @FXML private TableView<User> userTable;
    @FXML private TableColumn<User, String> usernameColumn;
    @FXML private TableColumn<User, String> emailColumn;
    @FXML private TableColumn<User, String> roleColumn;
    @FXML private TableColumn<User, String> statusColumn;
    @FXML private TableColumn<User, String> firstNameColumn;
    @FXML private TableColumn<User, String> lastNameColumn;
    @FXML private TableColumn<User, String> phoneNumberColumn;
    @FXML private TableColumn<User, String> addressColumn;

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private TextField emailField;
    @FXML private ComboBox<String> roleComboBox;
    @FXML private CheckBox statusCheckBox;
    @FXML private TextField firstNameField;
    @FXML private TextField lastNameField;
    @FXML private TextField phoneNumberField;
    @FXML private TextField addressField;
    @FXML private Button addButton;
    @FXML private Button updateButton;
    @FXML private Button deleteButton;
    @FXML private Button clearButton;
    @FXML private Label errorLabel;

    private ObservableList<User> userList = FXCollections.observableArrayList();

    public void initialize() {
        roleComboBox.setItems(FXCollections.observableArrayList("admin", "staff", "customer"));
        roleFilterComboBox.setItems(FXCollections.observableArrayList("All", "admin", "staff", "customer"));
        roleFilterComboBox.setValue("All");

        setupTableColumns();
        loadUsers();

        addButton.setOnAction(this::addUser);
        updateButton.setOnAction(this::updateUser);
        deleteButton.setOnAction(this::deleteUser);
        clearButton.setOnAction(e -> clearForm());

        userTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> populateForm(newSelection));
        roleFilterComboBox.setOnAction(e -> loadUsers());
        searchField.textProperty().addListener((obs, oldText, newText) -> loadUsers());
    }

    private void setupTableColumns() {
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        roleColumn.setCellValueFactory(new PropertyValueFactory<>("role"));
        statusColumn.setCellValueFactory(cellData ->
            new SimpleStringProperty(cellData.getValue().isStatus() ? "Active" : "Inactive")
        );
        firstNameColumn.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        lastNameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        phoneNumberColumn.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
        addressColumn.setCellValueFactory(new PropertyValueFactory<>("address"));
    }

    private void loadUsers() {
        userList.clear();
        String filterRole = roleFilterComboBox.getValue();
        String searchText = searchField.getText().toLowerCase();

        String query = "SELECT * FROM users WHERE (? = 'All' OR role = ?) AND "+
                       "(LOWER(username) LIKE ? OR LOWER(email) LIKE ? OR LOWER(first_name) LIKE ? OR LOWER(last_name) LIKE ?)";

        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, filterRole);
            stmt.setString(2, filterRole);
            for (int i = 3; i <= 6; i++) stmt.setString(i, "%" + searchText + "%");

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                userList.add(new User(
                        rs.getInt("user_id"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("email"),
                        rs.getString("role"),
                        rs.getBoolean("status"),
                        rs.getString("first_name"),
                        rs.getString("last_name"),
                        rs.getString("phone_number"),
                        rs.getString("address")
                ));
            }
        } catch (SQLException e) {
            errorLabel.setText("Failed to load users.");
            errorLabel.setVisible(true);
            e.printStackTrace();
        }

        userTable.setItems(userList);
    }

    private void addUser(ActionEvent event) {
        if (!validateInputs()) return;

        String query = "INSERT INTO users (username, password, email, role, status, first_name, last_name, phone_number, address) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, usernameField.getText());
            stmt.setString(2, passwordField.getText());
            stmt.setString(3, emailField.getText());
            stmt.setString(4, roleComboBox.getValue());
            stmt.setBoolean(5, statusCheckBox.isSelected());
            stmt.setString(6, firstNameField.getText());
            stmt.setString(7, lastNameField.getText());
            stmt.setString(8, phoneNumberField.getText());
            stmt.setString(9, addressField.getText());
            stmt.executeUpdate();
            loadUsers();
            clearForm();
        } catch (SQLException e) {
            errorLabel.setText("Failed to add user: " + e.getMessage());
            errorLabel.setVisible(true);
            e.printStackTrace();
        }
    }

    private void updateUser(ActionEvent event) {
        User selected = userTable.getSelectionModel().getSelectedItem();
        if (selected == null || !validateInputs()) return;

        String query = "UPDATE users SET username=?, password=?, email=?, role=?, status=?, first_name=?, last_name=?, phone_number=?, address=? WHERE user_id=?";

        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, usernameField.getText());
            stmt.setString(2, passwordField.getText());
            stmt.setString(3, emailField.getText());
            stmt.setString(4, roleComboBox.getValue());
            stmt.setBoolean(5, statusCheckBox.isSelected());
            stmt.setString(6, firstNameField.getText());
            stmt.setString(7, lastNameField.getText());
            stmt.setString(8, phoneNumberField.getText());
            stmt.setString(9, addressField.getText());
            stmt.setInt(10, selected.getUserId());
            stmt.executeUpdate();
            loadUsers();
            clearForm();
        } catch (SQLException e) {
            errorLabel.setText("Failed to update user: " + e.getMessage());
            errorLabel.setVisible(true);
            e.printStackTrace();
        }
    }

    private boolean validateInputs() {
        if (usernameField.getText().isEmpty() || passwordField.getText().isEmpty() ||
            emailField.getText().isEmpty() || roleComboBox.getValue() == null) {
            errorLabel.setText("Username, Password, Email, and Role are required.");
            errorLabel.setVisible(true);
            return false;
        }
        return true;
    }

    private void deleteUser(ActionEvent event) {
        User selected = userTable.getSelectionModel().getSelectedItem();
        if (selected == null) return;

        String query = "DELETE FROM users WHERE user_id = ?";

        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, selected.getUserId());
            stmt.executeUpdate();
            loadUsers();
            clearForm();
        } catch (SQLException e) {
            errorLabel.setText("Failed to delete user: " + e.getMessage());
            errorLabel.setVisible(true);
            e.printStackTrace();
        }
    }

    private void clearForm() {
        usernameField.clear();
        passwordField.clear();
        emailField.clear();
        roleComboBox.setValue(null);
        statusCheckBox.setSelected(false);
        firstNameField.clear();
        lastNameField.clear();
        phoneNumberField.clear();
        addressField.clear();
        errorLabel.setVisible(false);
        userTable.getSelectionModel().clearSelection();
    }

    private void populateForm(User user) {
        if (user == null) return;
        usernameField.setText(user.getUsername());
        passwordField.setText(user.getPassword());
        emailField.setText(user.getEmail());
        roleComboBox.setValue(user.getRole());
        statusCheckBox.setSelected(user.isStatus());
        firstNameField.setText(user.getFirstName());
        lastNameField.setText(user.getLastName());
        phoneNumberField.setText(user.getPhoneNumber());
        addressField.setText(user.getAddress());
    }
    
    @FXML
    private void handleLogout(ActionEvent event) {
        try {
            // Load the login view FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/ui/LoginView.fxml"));
            Parent loginRoot = loader.load();

            // Get the current stage and set the login scene
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loginRoot);
            stage.setScene(scene);
            stage.setTitle("Login");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}