package controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import utils.DatabaseConnector;

import java.io.IOException;
import java.sql.*;

public class AdminChartsController {

    @FXML
    private PieChart userPieChart;

    @FXML
    private BarChart<String, Number> genreBarChart;

    @FXML
    private LineChart<String, Number> rentalLineChart;

    @FXML
    public void initialize() {
        setupUserPieChart();
        setupGenreBarChart();
        setupRentalLineChart();
    }

    private void setupUserPieChart() {
        ObservableList<PieChart.Data> data = FXCollections.observableArrayList();
        String query = "SELECT role, COUNT(*) FROM users GROUP BY role";

        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                String role = rs.getString("role");
                int count = rs.getInt("count");
                data.add(new PieChart.Data(role, count));
            }
            userPieChart.setData(data);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void setupGenreBarChart() {
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Movies by Genre");

        String query = "SELECT genre, COUNT(*) AS total FROM movies GROUP BY genre ORDER BY genre";

        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                String genre = rs.getString("genre");
                int total = rs.getInt("total");
                series.getData().add(new XYChart.Data<>(genre, total));
            }

            genreBarChart.getData().clear();
            genreBarChart.getData().add(series);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void setupRentalLineChart() {
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Rentals Over Time");

        String query = "SELECT TO_CHAR(rental_date, 'YYYY-MM') AS month, COUNT(*) AS total " +
                       "FROM rentals GROUP BY month ORDER BY month";

        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                String month = rs.getString("month");
                int total = rs.getInt("total");
                series.getData().add(new XYChart.Data<>(month, total));
            }

            rentalLineChart.getData().clear();
            rentalLineChart.getData().add(series);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    @FXML
    private void handleLogout(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/ui/LoginView.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Login");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}