package application;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import controllers.CustomerDashboardController;
import controllers.SessionManager;
import utils.DatabaseConnector;

public class MainApp extends Application {

    private static Stage primaryStage;

    @Override
    public void start(Stage primaryStage) {
        try {
            DatabaseConnector.getConnection();
            MainApp.primaryStage = primaryStage;
            showLoginScreen();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void showLoginScreen() {
        loadScene("/ui/LoginView.fxml", "Movie Rental System - Login");
    }

    public static void showRegisterScreen() {
        loadScene("/ui/RegisterView.fxml", "Movie Rental System - Register");
    }

    public static void showDashboard() {
        String role = SessionManager.getCurrentUserRole();
        String fxmlPath = switch (role) {
            case "admin" -> "/ui/AdminDashboard.fxml";
            case "staff" -> "/ui/StaffDashboard.fxml";
            default -> "/ui/CustomerDashboard.fxml";
        };

        try {
            FXMLLoader loader = new FXMLLoader(MainApp.class.getResource(fxmlPath));
            Parent root = loader.load();

            // Inject session values if it's a customer
            if ("customer".equals(role)) {
                CustomerDashboardController controller = loader.getController();
                controller.initialize(
                    SessionManager.getCurrentUserId(),
                    SessionManager.getCurrentUsername(),
                    SessionManager.getCurrentUserEmail()
                );
            }

            Scene scene = new Scene(root);
            primaryStage.setTitle("Movie Rental System - Dashboard");
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private static void loadScene(String fxmlPath, String title) {
        try {
        	

            FXMLLoader loader = new FXMLLoader(MainApp.class.getResource(fxmlPath));
            Parent root = loader.load();

            Scene scene = new Scene(root);
            primaryStage.setTitle(title);
            primaryStage.setScene(scene);
            primaryStage.setResizable(false);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void main(String[] args) {
        launch(args);
    }
}
